//
//  Article.swift
//  Headlines WatchKit Extension
//
//  Created by Zac White on 9/30/19.
//  Copyright © 2019 Zac WHite. All rights reserved.
//

import UIKit

struct Article {
    let image: UIImage

    let headline: String
    let body: String
}

extension Article {
    static let testCorgiArticle = Article(
        image: UIImage(named: "corgi")!,
        headline: "Why thousands are flocking to corgi cafes",
        body: """
            Corgi cafes are all the rage, so what's behind the global phenomenon transforming the fortunes of this once overlooked dog breed?

            Corgi cafes are especially popular in Asia, with businesses thriving in Thailand, Japan and China.
            """
    )
}
