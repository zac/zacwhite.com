//
//  CGPoint+Extensions.swift
//
//  Created by Zac White on 9/30/19.
//  Copyright © 2019 Zac White. All rights reserved.
//

import CoreGraphics

extension CGPoint {
    static func - (lhs: CGPoint, rhs: CGPoint) -> CGPoint {
        return CGPoint(x: lhs.x - rhs.x, y: lhs.y - rhs.y)
    }
}
