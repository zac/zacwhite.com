//
//  HostingController.swift
//  Headlines WatchKit Extension
//
//  Created by Zac White on 9/24/19.
//  Copyright © 2019 Zac White. All rights reserved.
//

import WatchKit
import Foundation
import SwiftUI

class HostingController: WKHostingController<ArticleView> {
    override var body: ArticleView {
        return ArticleView(article: .testCorgiArticle)
    }
}
