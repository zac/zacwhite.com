SpaceCommander -.1
Written By: Do I have to give my name?

SpaceCommander puts little icons of all your running applications on the screen. It puts them in spacial order based on what space they are running in. To activate just press ctrl+~. Boom, SpaceCommander blasts off with its RETRO rocket.

Not good for practical things or winning this contest, but good source code for learning how to:

* Make a system wide hotkey.
* Get number of rows/columns in spaces preference.
* Get current space (kind of a hack).
* Get a list of all visible windows.
* Get information about those windows such as size, workspace, application, etc.
* Put a menuextra up in the menu bar (Was going to be a whole different feature).
* Tell OS X to switch spaces (grep for com.apple.switchSpaces).