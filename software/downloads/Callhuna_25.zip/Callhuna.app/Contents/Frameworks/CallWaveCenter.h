//
//  CallWaveCenter.h
//  VisualVoicemail
//
//  Created by Zac White on 4/26/07.
//  Copyright 2007 Zac White. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "CWCall.h"

@interface CallWaveCenter : NSObject {

}
+ (CallWaveCenter *)instance;

- (NSDictionary *)registerWithInformation:(NSString *)phone pin:(NSString *)pin email:(NSString *)email;
- (void)markCall:(CWCall *)call withStatus:(NSString *)status usingAccount:(NSString *)account andUUID:(NSString *)uuid;
- (NSString *)_responseForRequest:(NSString *)request fromURL:(NSURL *)url;
- (NSArray *)callDataForAccount:(NSString *)account uuid:(NSString *)uuid;
- (NSArray *)_processCalls:(NSArray *)xmlNodes;
@end
