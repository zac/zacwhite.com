//
//  WelcomeController.h
//  Callhuna
//
//  Created by Zac White on 7/23/07.
//  Copyright 2007 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>

#import "AGKeychain.h"

@interface WelcomeController : NSObject {
	IBOutlet NSWindow *window;
	
	IBOutlet NSTextField *numberField;
	IBOutlet NSSecureTextField *pinField;
	IBOutlet NSTextField *emailField;
	
	IBOutlet NSButton *continueButton;
	IBOutlet NSTextField *statusField;
	IBOutlet NSProgressIndicator *progressIndicator;
	
	BOOL done;
}


- (IBAction)continueAction:(id)sender;

- (void)_registerWithCallwave;

@end
