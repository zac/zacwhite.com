//
//  CWCall.h
//  VisualVoicemail
//
//  Created by Zac White on 4/26/07.
//  Copyright 2007 Zac White. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface CWCall : NSObject {
	NSDate *time;
	int cid;
	
	NSString *revStatus;
	
	//actual duration is this - 5.
	NSTimeInterval duration;
	
	NSString *caller;
	NSString *name;
	NSString *phoneType;
	
	NSString *description;
	
	NSURL *primaryURL;
	NSURL *secondaryURL;
	
	NSString *location;
	
	BOOL isNew;
}

- (NSDate *)time;
- (void)setTime:(NSDate *)aTime;
- (int)cid;
- (void)setCID:(int)aCID;
- (NSString *)revStatus;
- (void)setRevStatus:(NSString *)aRevStatus;
- (NSTimeInterval)duration;
- (void)setDuration:(NSTimeInterval)aDuration;
- (NSString *)caller;
- (void)setCaller:(NSString *)aCaller;
- (NSString *)name;
- (void)setName:(NSString *)aName;
- (NSString *)phoneType;
- (void)setPhoneType:(NSString *)aPhoneType;
- (NSString *)description;
- (void)setDescription:(NSString *)aDescription;
- (NSURL *)primaryURL;
- (void)setPrimaryURL:(NSURL *)aPrimaryURL;
- (NSURL *)secondaryURL;
- (void)setSecondaryURL:(NSURL *)aSecondaryURL;
- (NSString *)location;
- (void)setLocation:(NSString *)aLocation;
- (BOOL)isNew;
- (void)setIsNew:(BOOL)aIsNew;

@end
