//
//  PreferencesController.h
//  Callhuna
//
//  Created by Zac White on 7/23/07.
//  Copyright 2007 Zac White. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface PreferencesController : NSObject {
	IBOutlet NSWindow *preferencesWindow;
}

- (IBAction)showPreferences:(id)sender;
- (IBAction)updateLoginStatus:(id)sender;

- (void)_registerDefaults;


@end
