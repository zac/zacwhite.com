/*
 *  defines.h
 *
 *  Special thanks to Julian Cane for these ideas!
 *
 */
 
/* Basic Stuff */
#import <Foundation/Foundation.h>
#import <stdio.h>
#import <sys/types.h>
#import <unistd.h>
/* Classes */
#import <Sparkle/SUUpdater.h>
#import <SMPluginDownloader.h>
#import <SMPluginHandler.h>
#import <SMSearchPlugin.h>
#import <SMResultPlugin.h>
#import <SMPluginInstaller.h>
#import <SMURLRequest.h>
#import <PSContextSearch.h>
/* Controllers */
#import <SearchMagicController.h>
#import <PreferencesController.h>
#import <UpdateController.h>
/* ZWKit */
#import <ZWKit.h>

/* current plugin */
#define CURRENT_PLUGIN [[SMPluginHandler instance] searchPlugin]

/* user app support folder */
#define	APP_SUPPORT_FOLDER [@"~/Library/Application Support/SearchMagic/" stringByExpandingTildeInPath]
#define	SEARCH_PLUGIN_FOLDER [@"~/Library/Application Support/SearchMagic/Search Plugins/" stringByExpandingTildeInPath]
#define	RESULT_PLUGIN_FOLDER [@"~/Library/Application Support/SearchMagic/ResultView Plugins/" stringByExpandingTildeInPath]

/* debugging */

/* logging facilities */
#if(DEBUG_HEAVY)
/* For a debug build, declare the SMLog() function */
    #define SMLog(...) printf("SearchMagic[%u] %s\n", getpid(), [[NSString stringWithFormat:@"%@:%u: %@", [[NSString stringWithCString:__FILE__] lastPathComponent], __LINE__, [NSString stringWithFormat:__VA_ARGS__]] cString]);
#else
/* For a non-debug build, define it to be a comment so there is no overhead in using it liberally */
    #define SMLog(fmt, ...) /** */
#endif

/* Versioning */
#define appVer [[[[NSBundle bundleForClass:[self class]] infoDictionary] objectForKey:@"CFBundleVersion"] floatValue]
#define appVerString [[[NSBundle bundleForClass:[self class]] infoDictionary] objectForKey:@"CFBundleVersion"]
#define appBuildVerString [[[NSBundle bundleForClass:[self class]] infoDictionary] objectForKey:@"BuildVersion"]
#define appBuildDateString [[[NSBundle bundleForClass:[self class]] infoDictionary] objectForKey:@"BuildDate"]

/* allows us to use api's for platforms that support them */
#define JAGUAR		(floor(NSAppKitVersionNumber) < NSAppKitVersionNumber10_2_3)
#define PANTHER		(floor(NSAppKitVersionNumber) > NSAppKitVersionNumber10_2_3)
#define TIGER		(floor(NSAppKitVersionNumber) > 750)

/* release and set obj to nil */
#define delete(obj)	if (obj != nil) {[obj release]; obj = nil;}

/* user defaults */
#define userDefaults [NSUserDefaults standardUserDefaults]

/* workspace */
#define fileManager [NSFileManager defaultManager]
#define fileSize(p) [[[fileManager fileAttributesAtPath:p traverseLink:NO] objectForKey:NSFileSize] intValue]
#define resourceFullPath(p) [[[[NSBundle mainBundle] bundlePath] stringByAppendingPathComponent:@"Contents/Resources/"] stringByAppendingPathComponent:p]

/* Useful crap */
#ifndef forall
#define forall(collection, element) for(id _ ## element ## _enumerator = [collection objectEnumerator], element; element = [_ ## element ## _enumerator nextObject]; )
#endif

/* Min & Max */
#ifndef MIN
#define MIN(a,b) (a>b) ? b : a
#endif

#ifndef MAX
#define MAX(a,b) (a>b) ? a : b
#endif


/* NSNumber */

#ifndef NINT
#define NINT(a) [NSNumber numberWithInt: a]
#endif

#ifndef NFLOAT
#define NFLOAT(a) [NSNumber numberWithFloat: a]
#endif

#ifndef NBOOL
#define NBOOL(a) [NSNumber numberWithBool: a]
#endif

#ifndef NCHAR
#define NCHAR(a) [NSNumber numberWithChar: a]
#endif


/* String Equality */
#define EQUAL(a,b) [a isEqualToString:b]
