//
//  SMPluginInstaller.h
//  SearchMagic
//
//  Created by Zac White on 8/30/05.
//  Copyright 2005 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <defines.h>

@interface SMPluginInstaller : NSObject {

}

+ (SMPluginInstaller*)instance;
- (id)init;

- (BOOL)installAllPluginsFromBundle;
- (BOOL)installPluginWithPath:(NSString *)path shouldReplace:(BOOL)replace;
- (BOOL)installPluginFromBundleWithName:(NSString *)name shouldReplace:(BOOL)replace;
@end
