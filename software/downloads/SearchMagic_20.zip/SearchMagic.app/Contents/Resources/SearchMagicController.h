/* SearchMagic by Zac White
 * SearchMagic is a program that uses simple, xml plugins to search sites in real time. It also displays the
 * results in its own webview which is customizable by html plugins. The search plugins are easily created by
 * using regular expressions or a new type called SearchMagic expressions.
 *
 * SearchMagic Expressions:
 * SMEs rely on context to extract data. If you know exactly what is going to be outside of a certain data item,
 * SMEs are the best solution for finding it. For example, if you want the title of a link you would use an SME
 * like "<a href=%>*</a>". This statement will look for "<a href=" then ignore everything till ">" then get the
 * value in * by waiting till "</a>". The option to use SMEs will be up to the creator of the plugin.
 *
 * TODO:
 * Done - Create a parser that will grab the current plugin's regular expressions.
 * Done - Create a parser that will grab the info from the raw search text.
 * Done - Make the framework for the webview plugins so that it can read in these plugins.
 * Done - Create a menu that is populated with the plugin names.
 * Reconcidering for later release - Create a framework that will allow more extensive search plugins where the entire
 *   parsing job is farmed out.
 * Done - Make a converter for SearchMagic expressions so that they can be made into regular expressions.
*/

/* SearchMagicController */

#import <Cocoa/Cocoa.h>
#import "SMPluginHandler.h"
#import "SMSearchPlugin.h"
#import "PSContextSearch.h"
#import "SMPluginInstaller.h"
#import <defines.h>

@interface SearchMagicController : NSObject
{
    IBOutlet		NSSearchField *searchField;
    IBOutlet		NSWindow *myWindow;
	IBOutlet		NSWindow *welcomeWindow;
    IBOutlet		WebView *resultView;
    IBOutlet		NSProgressIndicator *progress;
    //IBOutlet        NSImageView *progressBackground;
    WebFrame		*mainFrame;
    NSArray			*pluginData;
    SMSearchPlugin	*currentPlugin;
    NSMenu			*searchMenu;
    NSMenuItem		*theMenu;
    SMPluginHandler	*pluginHandler;
	BOOL			firstTime;
}
- (IBAction)search:(id)sender;
- (void)doSearch;
- (void)updateWebView:(NSArray *)data;
- (void)loadAllPlugins:(NSNotification *)note;
- (void)reload:(NSNotification *)note;
- (NSString *)parseContent:(NSString *)rawText;
- (void)dealloc;
//- (void)resizeTheWindow:(id)sender height:(int)theHeight doAnimate:(BOOL)isAnimated;
@end
