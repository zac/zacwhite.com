#import <Foundation/Foundation.h>

@interface NSString (ZWExtensions)

- (int)checksum;
- (NSString *)urlSafeString;
+ (NSString *)bytesToString:(float)numBytes;
@end