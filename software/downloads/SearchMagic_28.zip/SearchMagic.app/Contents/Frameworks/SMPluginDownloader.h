//
//  SMPluginDownloader.h
//  SearchMagic
//
//  Created by Zac White on 7/3/05.
//  Copyright 2005 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface SMPluginDownloader : NSObject {

}

+ (SMPluginDownloader*)instance;
- (NSString *)downloadResultPlugin:(NSString *)filename;
- (NSString *)downloadSearchPlugin:(NSString *)filename;
- (NSMutableDictionary *)downloadPluginList;
- (id)init;

@end