#import <Foundation/Foundation.h>

@interface NSData (ZWExtensions)

//BZIP
//-(int)decompressBzip2ToPath:(NSString *)inPath;

// ZIP
-(NSData *)inflate;

//Seperation.
-(NSRange)rangeOfData:(NSData*)data;
-(NSRange)rangeOfData:(NSData*)data options:(unsigned)mask;
-(NSRange)rangeOfData:(NSData *)aData options:(unsigned)mask range:(NSRange)aRange;
-(NSArray*)componentsSeparatedByData:(NSData*)aSeparator;

@end