//
//  SMURLRequest.h
//  SearchMagic
//
//  Created by Zac White on 8/9/05.
//  Copyright 2005 Zac White. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "SMPluginHandler.h"


@interface SMURLRequest : NSObject {

}

+ (SMURLRequest *)instance;
- (NSString *)getResultsWithPlugin:(SMSearchPlugin *)plugin term:(NSString *)searchString;
- (id)init;
@end

@interface SMURLRequest (Private)
- (NSURLRequest *)_createURLRequestWithPlugin:(SMSearchPlugin *)plugin;
- (NSURL *)_urlFromString:(NSString *)inString;
- (NSData *)_generateFormDataWithField:(NSString *)field andValue:(NSString *)value;
@end