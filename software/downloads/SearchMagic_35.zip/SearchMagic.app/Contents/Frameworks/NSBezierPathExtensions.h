#import <Foundation/Foundation.h>

@interface NSBezierPath (ZWExtensions)

static void evaluate(void *info, const float *in, float *out);
-(void)linearGradientFill:(NSRect)thisRect startColor:(NSColor *)startColor endColor:(NSColor *)endColor;
float absDiff(float a, float b);

@end