//
//  ZWUpdater.h
//  SearchMagic
//
//  Created by Zac White on 6/9/06.
//  Copyright 2006 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface ZWUpdater : SUUpdater {
    
}

@end
