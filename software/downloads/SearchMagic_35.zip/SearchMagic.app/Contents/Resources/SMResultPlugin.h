//
//  SMResultPlugin.h
//  SearchMagic
//
//  Created by Zac White on 11/29/04.
//  Copyright 2004 Zac White. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "SMSearchPlugin.h"

@interface SMResultPlugin : NSObject {
    NSString	*resultBundleName;
    NSString	*resultName;
    NSString	*resultHeader;
    NSString	*resultFooter;
    NSString	*resultItem;
    NSString	*resultItemSpacer;
    NSString	*resultTemp;
    NSString	*resultNoResult;
    NSString    *resultDefaultPage;
}

- (NSString *)bundleName;
- (NSString *)name;
- (NSString *)header;
- (NSString *)footer;
- (NSString *)item;
- (NSString *)temp;
- (NSString *)noResult;
- (NSString *)defaultPage;
- (void)setBundleName:(NSString *)bundleName;
- (void)setName:(NSString *)name;
- (void)setHeader:(NSString *)header;
- (void)setFooter:(NSString *)footer;
- (void)setItem:(NSString *)item;
- (void)setItemSpacer:(NSString *)itemSpacer;
- (void)setTemp:(NSString *)temp;
- (void)setNoResult:(NSString *)noResult;
- (void)setDefaultPage:(NSString *)defaultPage;
//- (id)init;
- (NSString *)replaceTokens:(SMSearchPlugin *)plugin tokenValues:(NSDictionary *)parsed;
- (void)evaluateAllConditionals:(NSMutableString *)string forDict:(NSDictionary *)parsed;
@end