#import <Foundation/Foundation.h>
#import <AppKit/AppKit.h>

@interface NSMenu (ZWExtensions)

- (id <NSMenuItem>)itemWithTitle:(NSString *)title recursive:(BOOL)isRecursive;
- (id <NSMenuItem>)_findItemWithTitleRecursively:(NSString *)title inMenu:(NSMenu *)menu;
@end