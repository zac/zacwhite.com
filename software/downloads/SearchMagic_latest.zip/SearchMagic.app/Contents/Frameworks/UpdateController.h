/* UpdateController */

#import <Cocoa/Cocoa.h>

@interface UpdateController : NSObject
{
    IBOutlet NSTextField *authorField;
    IBOutlet NSTextField *descriptionField;
    IBOutlet NSTextField *nameField;
    IBOutlet NSTableView *pluginView;
    IBOutlet NSImageView *previewView;
    IBOutlet NSTextField *versionField;
    IBOutlet NSWindow *myWindow;
    IBOutlet NSPanel *updatePanel;
    IBOutlet NSView *browseView;
    IBOutlet NSView *updateView;
    IBOutlet NSButton *installButton;
    //installView stuff
    IBOutlet NSView *installView;
    IBOutlet NSTableView *installPluginView;
    IBOutlet NSTextField *installProgressText;
    IBOutlet NSTextField *installPluginName;
    IBOutlet NSProgressIndicator *installProgressIndicator;
    
    NSMutableDictionary *pluginList;
    NSMutableArray *checked;
    int count;
    int installNumber;
}
- (IBAction)install:(id)sender;
- (IBAction)installStop:(id)sender;

//NSTableView methods.
- (id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(int)rowIndex;
- (int)numberOfRowsInTableView:(NSTableView *)aTableView;

- (void)doInstall;

- (void)_updateButton;
@end
