#import <Cocoa/Cocoa.h>


@interface NSAttributedString (Extensions)
 
- (NSAttributedString*) attributedStringWithColor: (id) theColor;

- (NSAttributedString*) whiteAttributedString;
- (NSAttributedString*) whiteAttributedStringWithAlpha: (float) alpha;

@end