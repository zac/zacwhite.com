#import <Foundation/Foundation.h>

@interface NSData (ZWExtensions)

//BZIP
//-(int)decompressBzip2ToPath:(NSString *)inPath;

// ZIP
-(NSData *)inflate;

@end