#import <Foundation/Foundation.h>

@interface NSString (ZWExtensions)

- (int)checksum;
+ (NSString *)bytesToString:(float)numBytes;
@end