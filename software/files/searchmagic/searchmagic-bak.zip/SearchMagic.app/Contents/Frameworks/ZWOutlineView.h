//
//  ZWOutlineView.h
//  
//
//  Created by Zac White on 7/30/05.
//  Copyright 2005 Zac White. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface ZWOutlineView : NSOutlineView {
    id controller;
    id firstColumn;
    
    NSColor* white;
    NSColor* alternate;
    NSColor* secondary;
    
    NSImage* cache;
    
}

-(void)highlightSelectionInClipRect:(NSRect)clipRect;
-(id)_highlightColorForCell:(NSCell *)cell;

@end
