#import "ZWColor.h"
#import "ZWTableString.h"


@interface ZWTwoLevelTableCell : NSCell 
{
    @public
    int zwColorIndex;
    
    ZWTableString* primary;
    ZWTableString* secondary;
}

- (void) setPrimary:(NSString*)theString;
- (void) setSecondary:(NSString*)theString;

@end