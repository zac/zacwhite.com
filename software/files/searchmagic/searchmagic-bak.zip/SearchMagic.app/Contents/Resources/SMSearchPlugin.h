//
//  SMSearchPlugin.h
//  SearchMagic
//
//  Created by Zac White on 11/29/04.
//  Copyright 2004 Positron Software. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface SMSearchPlugin : NSObject {
	BOOL			post;
    NSString		*path;
    NSString		*name;
    NSString		*description;
    NSString		*version;
    NSString		*preURL;
    NSString		*postURL;
    NSString		*title;
    NSString		*desc;
    NSString		*url;
    NSDictionary	*extras;
	NSDictionary	*formData;
}
//accessors.
- (BOOL)post;
- (NSString *)path;
- (NSString *)name;
- (NSString *)version;
- (NSString *)preURL;
- (NSString *)postURL;
- (NSString *)title;
- (NSString *)desc;
- (NSString *)url;
- (NSDictionary *)extras;
- (NSDictionary *)formData;
- (void)setPost:(BOOL)thePost;
- (void)setName:(NSString *)theName;
- (void)setDesc:(NSString *)theDesc;
- (void)setURL:(NSString *)theURL;
- (void)setPreURL:(NSString *)thePre;
- (void)setPostURL:(NSString *)thePost;
- (void)setTitle:(NSString *)theTitle;
- (void)setExtras:(NSDictionary *)theExtras;
- (void)setFormData:(NSDictionary *)theFormData;


    //other methods.
- (NSDictionary *)tokenList;
//- (id)init;
@end