/* PreferencesController */

#import <Cocoa/Cocoa.h>

@interface PreferencesController : NSObject
{
    NSToolbar *toolbar;
    NSMutableDictionary *items;
    
    IBOutlet NSView *generalView;
    IBOutlet NSView *searchView;
    IBOutlet NSView *appearanceView;
    IBOutlet NSView *browseView;
    IBOutlet NSView *installView;
    IBOutlet WebView *previewView;
	//preference things.
	IBOutlet NSButton *progressIndicatorCheck;
	IBOutlet NSButton *resizeWindowCheck;
	IBOutlet NSPopUpButton *numResultsList;
	IBOutlet NSButton *searchAsYouTypeCheck;
	IBOutlet NSPopUpButton *popupList;
	WebFrame *mainFrame;
	
    IBOutlet NSWindow *myWindow;
}
//delegate methods.
- (NSToolbarItem *)toolbar:(NSToolbar *)toolbar itemForItemIdentifier:(NSString *)itemIdentifier willBeInsertedIntoToolbar:(BOOL)flag;
- (NSArray *)toolbarAllowedItemIdentifiers:(NSToolbar*)toolbar;
- (NSArray *)toolbarDefaultItemIdentifiers:(NSToolbar*)toolbar;
- (void)switchViews:(NSToolbarItem *)item;
- (IBAction)openWindow:(id)sender;
- (IBAction)changePreview:(id)sender;
- (IBAction)changePref:(id)sender;
- (void)loadPrefs;
- (void)buildPreview:(NSString *)title;
@end
