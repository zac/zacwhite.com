#import <Cocoa/Cocoa.h>


#define kZWColorWhiteIndex     0
#define kZWColorLightBlueIndex 1
#define kZWColorAlternateIndex 2
#define kZWColorSecondaryIndex 3
#define kZWColorTotalIndices   4


@interface ZWColor : NSObject 

+ (NSColor*) colorForIndex: (int) zwColorIndex;
+ (int) indexForColor: (NSColor*) theColor;

+ (NSColor*) whiteColor;
+ (NSColor*) grayColor30;
+ (NSColor*) grayColor;
+ (NSColor*) grayColor80;
+ (NSColor*) blackColor;
+ (NSColor*) lightBlueColor;
+ (NSColor*) alternateSelectedControlColor;
+ (NSColor*) secondarySelectedControlColor;

+ (NSColor*) whiteColorBlendedWithAlternate;

@end