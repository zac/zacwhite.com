#import "ZWConfinedString.h"


@interface ZWTableString : ZWConfinedString 
{
    ZWConfinedString* alternateString;
    NSColor* alternateColor;
}

- (void) setAlternateColor: (NSColor*) theColor;
- (ZWConfinedString*) alternateString;

@end


ZWTableString* ZWTableStringCreate(NSString* theString, NSDictionary* theAttributes);
ZWTableString* ZWTableStringCreateCached(NSString* theString, NSDictionary* theAttributes);
