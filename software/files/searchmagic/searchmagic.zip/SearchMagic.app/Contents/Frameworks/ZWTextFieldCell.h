//
//  ZWTextFieldCell.h
//  
//
//  Created by Zac White on 7/30/05.
//  Copyright 2005 Zac White. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface ZWTextFieldCell : NSTextFieldCell {
    
}

-(void)drawInteriorWithFrame:(NSRect)frame inView:(NSView *)view;

@end
