//
//  PSContextSearch.h
//  SearchMagic
//
//  Created by Zac White on 11/24/04.
//  Copyright 2004 __MyCompanyName__. All rights reserved.
//
// Sample ContextSearch string: "<a href=***>" returns whatever is in ***.
// Sample ContextSearch string: "<a href=*.*>***</a>" ignores whatever is in *.* and returns what is in ***.

#import <Cocoa/Cocoa.h>
#import <AGRegex/AGRegex.h>


@interface PSContextSearch : NSObject {
    AGRegex *regex;
}
- (NSMutableArray *)extractAllOccurrences:(NSString *)stringToParse cs:(NSString *)searchString;
//- (NSString *)extractFirstOccurrence:(NSString *)stringToParse cs:(NSString *)searchString;
@end
