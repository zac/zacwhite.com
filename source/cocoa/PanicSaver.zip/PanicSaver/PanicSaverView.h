//
//  PanicSaverView.h
//  PanicSaver
//
//  Created by Zac White on Sun Feb 08 2004.
//  Copyright (c) 2004, Positron Software. All rights reserved.
//

#import <ScreenSaver/ScreenSaver.h>


@interface PanicSaverView: ScreenSaverView 
{
    BOOL drawn;
    NSSize myBounds;
    NSBezierPath *path;
    NSTimer *timer;
    int width, height, i;
    NSBitmapImageRep *image;
    ScreenController *getscreen;
}

- (void)drawPanic;
- (void)drawPanicPanel;
@end
