//
//  PanicSaverView.m
//  PanicSaver
//
//  Created by Zac White on Sun Feb 08 2004.
//  Copyright (c) 2004, Positron Software. All rights reserved.
//

#import "ScreenController.h"
#import "PanicSaverView.h"


@implementation PanicSaverView
//this stops the fade in from happening.
+ (BOOL)performGammaFade
{
    return NO;
}

- (id)initWithFrame:(NSRect)frame isPreview:(BOOL)isPreview
{
    if(!isPreview){  //for some reason, preview doesn't work. This might be fixed later.
	getscreen = [[ScreenController alloc] init];
    
	NSSize size = {10000, 10000};

	//free the old memory in _screenBytes
	[getscreen setScreenCapture:nil];

	[getscreen setScreenCapture:[getscreen _makeNSImageFromScreen:size]];
    }
    self = [super initWithFrame:frame isPreview:isPreview];
    if (self) {
	[self setAnimationTimeInterval:1/60.0];
    }
    return self;
}

- (void)startAnimation
{
    [super startAnimation];
}

- (void)stopAnimation
{
    [super stopAnimation];
}

- (void)drawRect:(NSRect)rect
{
    [super drawRect:rect];
}

- (void)animateOneFrame
{
    if (!drawn){  //only do this once.
        myBounds = [self bounds].size;  //get screen size
	[getscreen displayImage];
	[self drawPanic];
    }
    drawn = YES;
    return;
}

- (BOOL)hasConfigureSheet
{
    return NO;
}

- (NSWindow*)configureSheet
{
    return nil;
}

- (void)drawPanic
{
    width = myBounds.width;  //get screen dimentions.
    height = myBounds.height;
    
    //NSLog(@"Width = %d Height = %d", width, height);
    [path setLineWidth: 1];
    i = height / 2;
    timer = [[NSTimer scheduledTimerWithTimeInterval:(.002) target:self selector:@selector(drawLine:) userInfo:nil repeats:YES] retain];
    [path closePath];
}

- (void)drawLine:(NSTimer *)aTimer
{
    [[NSColor colorWithCalibratedRed:0. green:0. blue:0. alpha:0.6] set];
    if(i > 0){
	[NSBezierPath strokeLineFromPoint:NSMakePoint(0, 2 * i) toPoint:NSMakePoint(width, 2 * i)];
	i--;
    }else{
	[timer invalidate];  //we are done with the timer now.
	[timer release];  //release it.
	[self drawPanicPanel];  //draw the panel.
    }
}

- (void)drawPanicPanel
{
    NSBitmapImageRep *kernelPict = nil;
    NSSize imageSize;
    NSRect drawLocation;
    
    kernelPict = [NSBitmapImageRep imageRepWithContentsOfFile: [[NSBundle bundleForClass:[self class]] pathForResource: [NSString stringWithFormat:@"kernel.jpg"] ofType:@""]]; //just change kernel.jpg to anything you want.
    if (kernelPict) {
        imageSize.height = [kernelPict pixelsHigh];  //this way, it is the same size no matter the res.
        imageSize.width = [kernelPict pixelsWide];
		
	[kernelPict setSize: imageSize];
    
	imageSize = [kernelPict size];
	drawLocation.origin = NSMakePoint((width/2) - (imageSize.width/2), (height/2) - (imageSize.height/2)); //center it.
	drawLocation.size = imageSize;
	[kernelPict drawInRect: drawLocation];
    }else{
	NSLog(@"Error: Couldn't load kernel pict");
    }
}

- (void)dealloc
{
    [getscreen release];
    [image release];
    [super dealloc];
}
@end