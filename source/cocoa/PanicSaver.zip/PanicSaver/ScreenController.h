/*
ScreenController.h

ScreenCapture: a demo app to show how to make an NSImage containing a screen capture.

Feel free to use this code anywhere you'd like, just make sure to give Josh Anon credit
for writing it and Michael Trent credit for helping to debug it.

CHANGELOG:
2/25/03: Marco Pontil updated capture method to use bitshifts and take a size parameter
 (does some simple sampling if size < screen size)

 Code cleaned up somewhat to follow better coding practices
 
9/15/02: Cleaned up RGBA conversion code thanks to Tim Willamson
1/31/02: Finally fixed the problem w/ 10.1.  -initWithBitmapDataPlanes... only refs the
        data if you pass in a planes pointer, but it was being freed shortly thereafter.
        Made screenBytes global and moved free into dealloc.  Thanks to Tommaso Pecorella
        for pointing this out.  
*/

#import <Cocoa/Cocoa.h>
#import <ApplicationServices/ApplicationServices.h>

@interface ScreenController : NSObject
{
    NSImage *_screenCapture;
    unsigned char *_screenBytes;
}

-(id)init;
-(NSImage*)screenCapture;
-(void)setScreenCapture:(NSImage*)sc;
-(void)displayImage;

@end
