/*
ScreenController.m

ScreenCapture: a demo app to show how to make an NSImage containing a screen capture.

Feel free to use this code anywhere you'd like, just make sure to give Josh Anon credit
for writing it and Michael Trent credit for helping to debug it. 

*/

#import "ScreenController.h"

@interface ScreenController(Private)
-(NSImage *)_makeNSImageFromScreen:(NSSize)size;
@end

@implementation ScreenController

-(id)init {
    if (self = [super init]) {
        //_screenCapture should be nil, but we do this to set
        //_screenBytes to NULL
        [self setScreenCapture:nil];
    }

    return self;
}

-(void)awakeFromNib {
    [self captureScreen:nil];
}

-(NSImage*)screenCapture {
    if (!_screenCapture)
        [self captureScreen:nil];
    
    return _screenCapture;
}

-(void)setScreenCapture:(NSImage*)sc {
    if (sc != _screenCapture) {
        [sc retain];
        [_screenCapture release];
        _screenCapture = sc;

        if (sc == nil) {
            free(_screenBytes);
            _screenBytes = NULL;
        }
    }
}


/*-(IBAction)captureScreen:(id)sender {
    NSSize size = {10000, 10000};

    //free the old memory in _screenBytes
    [self setScreenCapture:nil];

    [self setScreenCapture:[self _makeNSImageFromScreen:size]];
    [self displayImage];
}*/

-(void)displayImage {
    [_screenCapture compositeToPoint:NSMakePoint(0,0) operation:NSCompositeCopy];
    //[imageView setImage:_screenCapture];
    //[imageView setNeedsDisplay];
}


-(void)dealloc {
    [self setScreenCapture:nil];
    [super dealloc];
}

@end

@implementation ScreenController(Private)
-(NSImage *)_makeNSImageFromScreen:(NSSize)size {
    NSBitmapImageRep *_screenCaptureBitmap;
    int bPerPixel, bPerSample, sPerPixel, byPerRow, byPerPixel, w, h;
    NSImage *capture;
    unsigned char *_screenBytesActual;

    // Gets the screen dimensions:
    w = CGDisplayPixelsWide(kCGDirectMainDisplay);
    h = CGDisplayPixelsHigh(kCGDirectMainDisplay);

    // Fix the destination size so it is not bigger that the source
    // (this means we can resize only to smaller images)
    if (size.height > h)
        size.height = h;

    if (size.width > w)
        size.width = w;

    // Gets the base of the screen memory:
    _screenBytesActual = (unsigned char *)CGDisplayBaseAddress(kCGDirectMainDisplay);

    //need to copy the bytes so we can swap them.
    if (_screenBytes != NULL)
        free (_screenBytes);

    _screenBytes = (unsigned char*)malloc(size.width * size.height * 4);

    // Gets all the screen info:
    bPerPixel = CGDisplayBitsPerPixel(kCGDirectMainDisplay);
    bPerSample = CGDisplayBitsPerSample(kCGDirectMainDisplay);
    sPerPixel =  CGDisplaySamplesPerPixel(kCGDirectMainDisplay);
    byPerRow = CGDisplayBytesPerRow(kCGDirectMainDisplay);
    byPerPixel = bPerPixel / 8;

    if (_screenBytes != 0)
    {
        // Finds how much we need to resize:
        int xSource, ySource, xDestination, yDestination, deltaX, deltaY;

        // the delta steps are:
        deltaX = (((float)w / (float)size.width) + 0.5);
        deltaY = (((float)h / (float)size.height) + 0.5);

        // Copy the screen memory in the new buffer resizing it and "fixing" the pixels:
        for (ySource = 0, yDestination = 0; ySource < h; ySource += deltaY, yDestination++)
        {
            // Pre calucalte this here to save time:

            unsigned long stepSource = ySource * byPerRow;
            unsigned long stepDestination = yDestination * (size.width * 4);

            for (xSource = 0, xDestination = 0; xSource < w; xSource += deltaX, xDestination++)
            {
                unsigned long newPixel;

                if (bPerPixel == 16)
                {
                    unsigned short thisPixel;

                    // Finds the begin of this pixel:
                    thisPixel = *((unsigned short*)(_screenBytesActual + (xSource * byPerPixel) + stepSource));

                    // Transformation is 0xARGB (with 1555) to 0xR0G0B0A0 with 4444
                    newPixel = thisPixel;
                    newPixel =	(((newPixel & 0x8000) >> 15) * 0xF8) 	/* A */ |
                        ((newPixel & 0x7C00) << 17)		/* R */ |
                        ((newPixel & 0x03E0) << 14)		/* G */ |
                        ((newPixel & 0x001F) << 11)		/* B */ ;
                }
                else if (bPerPixel == 32)
                {
                    unsigned long thisPixel;

                    // Finds the beginning of this pixel:
                    thisPixel = *((unsigned long*)(_screenBytesActual + (xSource * byPerPixel) + stepSource));

                    // Transformation is 0xAARRGGBB to 0xRRGGBBAA
                    newPixel = ((thisPixel & 0xFF000000) >> 24) |  ((thisPixel & 0x00FFFFFF) << 8);
                }

                // Sets the new pixel, and just in case check for the postion:
                if ((xDestination < size.width) && (yDestination < size.height))
                    *((unsigned long*)(_screenBytes + (xDestination * 4) + stepDestination)) = newPixel;
            }
        }
    }

    //Phew! create a bitmap w/ the screen capture
    _screenCaptureBitmap = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:&_screenBytes
                                                                   pixelsWide:size.width
                                                                   pixelsHigh:size.height
                                                                bitsPerSample:8
                                                              samplesPerPixel:3
                                                                     hasAlpha:NO
                                                                     isPlanar:NO
                                                               colorSpaceName:NSCalibratedRGBColorSpace
                                                                  bytesPerRow:(size.width * 4)
                                                                 bitsPerPixel:32];

    capture = [[NSImage alloc] initWithSize:[_screenCaptureBitmap size]];
    [capture addRepresentation:_screenCaptureBitmap];

    NSAssert(capture != nil, @"Screen capture failed!");

    [_screenCaptureBitmap release];
    return [capture autorelease];
}

@end
