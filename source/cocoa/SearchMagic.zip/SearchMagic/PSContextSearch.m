//
//  PSContextSearch.m
//  SearchMagic
//
//  Created by Zac White on 11/24/04.
//  Copyright 2004 __MyCompanyName__. All rights reserved.
//
#import "PSContextSearch.h"

/*!
 * @brief Extracts certain strings from string given a regular expression.
 */
@implementation PSContextSearch
//- (NSArray *)extractAllOccurrences:(NSString *)stringToParse cs:(NSString *)searchString{
//    int i,x;
//    NSArray *info; //the info around the text we want.
//    NSArray *results;
//    NSArray *temp;
//    NSMutableArray *returnResult = [[NSMutableArray alloc] init];
//    NSString *tempString;
//    NSString *pattern;
//    //save all the interesting bits around "*.*"s and "***"s and store it in an NSArray of 2 NSArrays.
//    temp = [searchString componentsSeparatedByString:@"***"]; //there should only be one of these.
//    info = [NSArray arrayWithObjects:[[temp objectAtIndex:0] componentsSeparatedByString:@"*.*"],
//	[[temp objectAtIndex:1] componentsSeparatedByString:@"*.*"], nil];
//    //[temp release];
//    
//	//NSLog(@"Info:%@", [info description]);
//    
//	//replace ***s and *.*s with .+?s to make it into a valid regular expression.
//    regex = [AGRegex regexWithPattern:@"\\*\\.\\*"];
//    searchString = [regex replaceWithString:@".+?" inString:searchString];
//    regex = [AGRegex regexWithPattern:@"\\*\\*\\*"];
//    searchString = [regex replaceWithString:@".+?" inString:searchString];
//    //searchString now has a valid (probably) regular expression which we can use to match the string.
//    regex = [AGRegex regexWithPattern:searchString];
//    results = [regex findAllInString:stringToParse];
//    NSLog(@"Results:%@", [results description]);
//    //Now we strip the extra crap that is in info. And return what we think *** is.
//    for(x = 0; x < [results count]; x++){  //go through each result.
//	tempString = [[results objectAtIndex:x] group];
//	//NSLog(@"tempString=%@", tempString);
//	for(i = 0; i < [info count]; i++){  //it better do this loop only twice...once for each side of ***
//	    //NSLog(@"YO:%d", [[info objectAtIndex:i] description]);
//	    /*for(j = 0; j < [[info objectAtIndex:i] count]; j++){  //this one goes once more than the number of *.*
//		regex = [AGRegex regexWithPattern:[[info objectAtIndex:i] objectAtIndex:j]];
//		tempString = [regex replaceWithString:@"" inString:tempString limit:1];
//	    }*/
//	    if([[info objectAtIndex:i] count] > 1){
//		pattern = [[NSString alloc] initWithFormat:@"%@.+?%@",
//		    [[info objectAtIndex:i] objectAtIndex:0],
//		    [[info objectAtIndex:i] objectAtIndex:[[info objectAtIndex:i] count] - 1]];  //takes the first and last and puts a .+? between.
//		regex = [AGRegex regexWithPattern:pattern];
//		//[pattern release];
//		NSLog(@"YO:%@", [[info objectAtIndex:i] description]);
//	    }else{
//		regex = [AGRegex regexWithPattern:[[info objectAtIndex:i] objectAtIndex:0]];
//	    }
//	    tempString = [regex replaceWithString:@"" inString:tempString limit:1];
//	}
//	[returnResult addObject:tempString];
//    }
//    //[regex release];
//    //[tempString release];
//    [returnResult autorelease];
//    //NSLog(@"returnResult:%@", [returnResult description]);
//    NSLog(@"Found: %@ with %@", [returnResult description], searchString);
//    return returnResult;
//}

- (NSMutableArray *)extractAllOccurrences:(NSString *)stringToParse cs:(NSString *)searchString
{
    NSMutableArray *bigList = [[NSMutableArray alloc] init];
    int i;
    regex = [[AGRegex alloc] initWithPattern:searchString options:AGRegexMultiline | AGRegexCaseInsensitive];
    NSArray *totalList = [regex findAllInString:stringToParse];
    for(i = 0; i < [totalList count]; i++){
	[bigList addObject:[[totalList objectAtIndex:i] groupAtIndex:1]];
    }
    [regex release];
    [bigList autorelease];
    return bigList;
}

- (void)dealloc
{
    //[regex release];
    [super dealloc];
}
@end