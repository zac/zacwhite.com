#import "PreferencesController.h"
#import "SMPluginHandler.h"

/*!
 * @brief The main controller for the Preferences window.
 */
@implementation PreferencesController

- (void)awakeFromNib
{
	items = [[NSMutableDictionary alloc] init];
    
    NSToolbarItem *item = [[NSToolbarItem alloc] initWithItemIdentifier:@"General"];
    [item setPaletteLabel:@"General"];
    [item setLabel:@"General"];
    [item setToolTip:@"General preference options."];
    [item setImage:[[NSImage alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"General" ofType:@"tiff"]]];
    [item setTarget:self];
    [item setAction:@selector(switchViews:)];
    [items setObject:item forKey:@"General"];
    [item release];
    
    item = [[NSToolbarItem alloc] initWithItemIdentifier:@"Search"];
    [item setPaletteLabel:@"Search"];
    [item setLabel:@"Search"];
    [item setToolTip:@"Preference options that pertain to searching."];
    [item setImage:[[NSImage alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"Search" ofType:@"tiff"]]];
    [item setTarget:self];
    [item setAction:@selector(switchViews:)];
    [items setObject:item forKey:@"Search"];
    [item release];
    
    item = [[NSToolbarItem alloc] initWithItemIdentifier:@"Appearance"];
    [item setPaletteLabel:@"Appearance"];
    [item setLabel:@"Appearance"];
    [item setToolTip:@"Appearance preference options."];
    [item setImage:[[NSImage alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"Appearance" ofType:@"tiff"]]];
    [item setTarget:self];
    [item setAction:@selector(switchViews:)];
    [items setObject:item forKey:@"Appearance"];
    [item release];
    
    /*
	item = [[NSToolbarItem alloc] initWithItemIdentifier:@"Update"];
    [item setPaletteLabel:@"Update"];
    [item setLabel:@"Update"];
    [item setToolTip:@"Update preference options."];
    [item setImage:[[NSImage alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"Update" ofType:@"tiff"]]];
    [item setTarget:self];
    [item setAction:@selector(switchViews:)];
    [items setObject:item forKey:@"Update"];
    [item release];
	*/
    
    toolbar = [[NSToolbar alloc] initWithIdentifier:@"preferencePanes"];
    [toolbar setDelegate:self];
    [toolbar setAllowsUserCustomization:NO];
    [toolbar setAutosavesConfiguration:NO];
    [myWindow setToolbar:toolbar];
	[toolbar release];
    [myWindow center];
    [self switchViews:nil];
}

//- (BOOL)validateMenuItem:(NSMenuItem *)menuItem{
//    return ([menuItem action] == @selector(openWindow:));
//}

- (IBAction)openWindow:(id)sender
{
	[popupList removeAllItems];
	[popupList addItemsWithTitles:[[[SMPluginHandler instance] resultPlugins] allKeys]];
	//if the userDefaults file doesn't exist, nil will be passed all the way through to changePreview which will create the key.
	if([userDefaults objectForKey:@"resultPlugin"]){
		[popupList selectItemWithTitle:[userDefaults objectForKey:@"resultPlugin"]];
		[self changePreview:popupList];
	}else{
		[self changePreview:nil];
	}
	[self loadPrefs];
	[myWindow center];
    [myWindow makeKeyAndOrderFront:self];
}

//toolbar delegate methods.

- (NSToolbarItem *)toolbar:(NSToolbar *)toolbar itemForItemIdentifier:(NSString *)itemIdentifier willBeInsertedIntoToolbar:(BOOL)flag
{
    return [items objectForKey:itemIdentifier];
}

- (NSArray *)toolbarAllowedItemIdentifiers:(NSToolbar*)theToolbar
{
    return [self toolbarDefaultItemIdentifiers:theToolbar];
}

- (NSArray *)toolbarDefaultItemIdentifiers:(NSToolbar*)theToolbar
{
    //return [NSArray arrayWithObjects:@"General", @"Search", @"Appearance", @"Update", nil];
	return [NSArray arrayWithObjects:@"General", @"Search", @"Appearance", nil];
}

//make all of them selectable.
- (NSArray *)toolbarSelectableItemIdentifiers: (NSToolbar *)toolbar
{
    return [items allKeys];
}

//called everytime a toolbar item is cilcked. If nil, return the default ("General").
- (void)switchViews:(NSToolbarItem *)item
{
    NSString *sender;
    if(item == nil){
        sender = @"General";
        [toolbar setSelectedItemIdentifier:sender];
    }else{
        sender = [item label];
    }
    NSView *prefsView;
    [myWindow setTitle:sender];
    if(EQUAL(sender, @"General")){
        prefsView = generalView;
    }else if(EQUAL(sender, @"Search")){
        prefsView = searchView;
    }else if(EQUAL(sender, @"Appearance")){
        prefsView = appearanceView;
    }/*else if(EQUAL(sender, @"Update")){
        prefsView = browseView;
    }*/
    
    NSView *tempView = [[NSView alloc] initWithFrame:[[myWindow contentView] frame]];
    [myWindow setContentView:tempView];
    [tempView release];
    
	NSRect newFrame = [myWindow frame];
    newFrame.size.height = [prefsView frame].size.height + ([myWindow frame].size.height - [[myWindow contentView] frame].size.height);
    newFrame.size.width = [prefsView frame].size.width;
    newFrame.origin.y += ([[myWindow contentView] frame].size.height - [prefsView frame].size.height);
    
    [myWindow setShowsResizeIndicator:YES];
    [myWindow setFrame:newFrame display:YES animate:YES];
    [myWindow setContentView:prefsView];
}

- (IBAction)changePreview:(id)sender{
	if(sender == nil){
		SMLog(@"sender == nil");
		[self buildPreview:[[popupList itemAtIndex:0] title]];
		[userDefaults setObject:[[popupList itemAtIndex:0] title] forKey:@"resultPlugin"];
		return;
	}
	SMLog(@"Preview change: %@", [sender titleOfSelectedItem]);
	[userDefaults setObject:[sender titleOfSelectedItem] forKey:@"resultPlugin"];
	[self buildPreview:[sender titleOfSelectedItem]];
	//post a notification so that we can reload the main view.
	NSNotificationCenter *nc = [NSNotificationCenter defaultCenter];
	[nc postNotificationName:@"ZWReloadView" object:self];
}

- (IBAction)changePref:(id)sender{
	switch([sender tag]){
		case 0: //show progress indicator.
			[userDefaults setInteger:[sender state] forKey:@"progressIndicator"];
			break;
		case 1: //resize window.
			[userDefaults setInteger:[sender state] forKey:@"resizeWindow"];
			break;
		case 2: //number of results per page.
			[userDefaults setInteger:[sender indexOfSelectedItem] forKey:@"numResults"];
			break;
		case 3: //search as you type.
			[userDefaults setInteger:[sender state] forKey:@"searchAsYouType"];
			NSNotificationCenter *nc = [NSNotificationCenter defaultCenter];
			[nc postNotificationName:@"ZWSearchAsYouType" object:NBOOL([sender state])];
			break;
		default: break;
	}
}

- (void)loadPrefs{
	if(![userDefaults objectForKey:@"progressIndicator"]){
		[userDefaults setInteger:NSOnState forKey:@"progressIndicator"];
		SMLog(@"No user defaults for progress");
		[progressIndicatorCheck setState:NSOnState];
	}else{
		[progressIndicatorCheck setState:[userDefaults integerForKey:@"progressIndicator"]];
	}
	if(![userDefaults objectForKey:@"resizeWindow"]){
		[userDefaults setInteger:NSOffState forKey:@"resizeWindow"];
		[resizeWindowCheck setState:NSOffState];
	}else{
		[resizeWindowCheck setState:[userDefaults integerForKey:@"resizeWindow"]];
	}
	if(![userDefaults objectForKey:@"searchAsYouType"]){
		[userDefaults setInteger:NSOnState forKey:@"searchAsYouType"];
		[searchAsYouTypeCheck setState:NSOnState];
	}else{
		[searchAsYouTypeCheck setState:[userDefaults integerForKey:@"searchAsYouType"]];
	}
	if(![userDefaults objectForKey:@"numResults"]){
		[userDefaults setInteger:0 forKey:@"numResults"];
		[numResultsList selectItemAtIndex:0];
	}else{
		[numResultsList selectItemAtIndex:[userDefaults integerForKey:@"numResults"]];
	}
}

- (void)buildPreview:(NSString *)title{
    [title retain];
	SMLog(@"Building preview with %@", title);
	NSMutableDictionary *tempList = [[NSMutableDictionary alloc] init];
	SMResultPlugin *plugin;
//	int i;
//	BOOL found = NO;
//	for(i = 0; i < [pluginList count]; i++){
//		if(EQUAL([[pluginList objectAtIndex:i] name], title)){
//			plugin = [[pluginList objectAtIndex:i] retain];
//			found = YES;
//			break;
//		}
//	}
	SMLog(@"%@", [[[SMPluginHandler instance] resultPlugins] objectForKey:title]);
    plugin = [[[[SMPluginHandler instance] resultPlugins] objectForKey:title] retain];
	if(plugin){
		[[SMPluginHandler instance] setCurrentResultPlugin:plugin];
		SMLog(@"Setting up fake dictionary.");
		[tempList setObject:[NSArray arrayWithObjects:@"This is an item.", @"This is an item.", @"This is an item", @"This is an item", @"This is an item", nil] forKey:@"%description"];
		[tempList setObject:[NSArray arrayWithObjects:@"Item", @"Item", @"Item", @"Item", @"Item", nil] forKey:@"%title"];
		[tempList setObject:[NSArray arrayWithObjects:@"nil", @"nil", @"nil", @"nil", @"nil", nil] forKey:@"%url"];
		[tempList setObject:[NSArray arrayWithObject:@"Engine"] forKey:@"%engine"];
		[tempList setObject:[NSArray arrayWithObject:@"5"] forKey:@"%numResults"];
		[tempList setObject:[NSArray arrayWithObject:@"Item"] forKey:@"%term"];
		[tempList setObject:[NSArray arrayWithObject:[NSString stringWithFormat:@"file:///Users/zac/Library/Application Support/SearchMagic/ResultView Plugins/%@/Contents/Resources", title]] forKey:@"%support"];
	
		NSString *tempData = [[plugin replaceTokens:CURRENT_PLUGIN tokenValues:tempList] retain];
		[tempList release];
		mainFrame = [previewView mainFrame];
		[mainFrame loadHTMLString:tempData baseURL:nil];
        [plugin release];
	}else{
		SMLog(@"Error: not found");
	}
    [title release];
}

- (void)dealloc
{
    [super dealloc];
    [toolbar release];
    [items release];
}



@end
