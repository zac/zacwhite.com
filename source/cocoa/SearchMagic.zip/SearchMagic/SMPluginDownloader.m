//
//  SMPluginDownloader.m
//  SearchMagic
//
//  Created by Zac White on 7/3/05.
//  Copyright 2005 Zac White. All rights reserved.
//

#import "SMPluginDownloader.h"

/*!
 * @brief Allows for the downloading and installing of plugins from a website.
 */
@implementation SMPluginDownloader

static id instance = nil;
+ (SMPluginDownloader*)instance
{
    if (!instance) instance = [[SMPluginDownloader alloc] init];
    return instance;
}

- (NSString *)downloadResultPlugin:(NSString*)filename
{
    //run plugin.sh with the name of the file and the -r flag.
    SMLog(@"Downloading and Installing Result plugin %@", filename);
    NSTask *theTask = [[NSTask alloc] init];
    
    [theTask setLaunchPath:[[NSBundle mainBundle] pathForResource:@"plugin" ofType:@"sh"]];
    [theTask setArguments:[NSArray arrayWithObjects:@"-r", filename, nil ]];
    [theTask launch];
    [theTask waitUntilExit];
    if([theTask terminationStatus] == 1){ //the file already exists.
	//maybe display some sort of overwrite dialog that reads both versions?
	SMLog(@"The plugin already exists. It was not overwritten");
    }
}

- (NSString *)downloadSearchPlugin:(NSString*)filename
{
    //run plugin.sh with the name of the file and the -s flag.
    SMLog(@"Downloading and Installing Search plugin %@", filename);
    NSTask *theTask = [[NSTask alloc] init];
    
    [theTask setLaunchPath:[[NSBundle mainBundle] pathForResource:@"plugin" ofType:@"sh"]];
    [theTask setArguments:[NSArray arrayWithObjects:@"-s", filename, nil ]];
    [theTask launch];
    [theTask waitUntilExit];
    if([theTask terminationStatus] == 1){ //the file already exists.
		//maybe display some sort of overwrite dialog that reads both versions?
		SMLog(@"The plugin %@ already exists. It was not overwritten", filename);
    }
}

- (NSMutableDictionary *)downloadPluginList
{
	//SMLog(@"Downloading plugins...");
    //return [NSDictionary dictionaryWithContentsOfURL:[NSURL URLWithString:@"http://homepage.mac.com/zacwhite/plugins.xml"]];
	return nil;
}

- (id)init
{
    SMLog(@"INIT:SMPluginDownloader");
    if(self = [super init]) instance = self;
    return self;
}

@end