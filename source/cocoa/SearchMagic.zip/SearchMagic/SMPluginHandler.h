//
//  SMPluginHandler.h
//  SearchMagic
//
//  Created by Zac White on 9/9/04.
//  Copyright 2004 Positron Software. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "defines.h"
#import "SMSearchPlugin.h"
#import "SMResultPlugin.h"

@interface SMPluginHandler : NSObject
{
    NSDictionary		*resultPlugins;
	NSMutableDictionary	*searchPlugins;
	NSMenu				*pluginMenu;
    SMResultPlugin		*currentResultPlugin;
    SMSearchPlugin		*currentSearchPlugin;
    int					currentSearchIndex;
}
+ (SMPluginHandler*)instance;
- (NSMenu *)pluginMenu;
- (NSMenu *)loadAllPlugins;
- (BOOL)loadResultPlugins;
- (NSMenu *)loadSearchPlugins:(NSString *)path;
- (SMResultPlugin *)resultPlugin;
- (SMSearchPlugin *)searchPlugin;
- (NSDictionary *)resultPlugins;
- (void)setSearchPluginPrefs;
- (void)switchPlugin:(id)sender;
- (void)setCurrentSearchPlugin:(SMSearchPlugin *)plugin;
- (void)setCurrentResultPlugin:(SMResultPlugin *)plugin;
- (id)init;
@end
