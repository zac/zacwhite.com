//
//  SMPluginHandler.m
//  SearchMagic
//  Description:
//  This class handles all the plugins that this program is capable of dealing with.
//  Including search and result plugins.
//  If i'm going to add a plugin, it should go in here.
//  NOTE: This is a singleton.
//
//  Created by Zac White on 9/9/04.
//  Copyright 2004 Positron Software. All rights reserved.
//
#import "SMPluginHandler.h"

/*!
 * @brief This class handles all the plugins that this program is capable of dealing with, including search and result plugins.
 */
@implementation SMPluginHandler

static id instance = nil;
+ (SMPluginHandler*)instance
{
    if (!instance) instance = [[SMPluginHandler alloc] init];
    return instance;
}

- (NSMenu *)pluginMenu{
	return pluginMenu;
}

#pragma mark Loading
- (NSMenu *)loadAllPlugins
{
    SMLog(@"Loading All Plugins");
    if(![self loadResultPlugins]){
		NSAlert *alert = [[NSAlert alloc] init];
		[alert addButtonWithTitle:@"OK"];
		[alert setMessageText:@"There doesn't seem to be a ResultView plugin folder."];
		[alert setInformativeText:@"You should have one. Try reinstalling SearchMagic."];
		[alert setAlertStyle:NSWarningAlertStyle];
		[alert runModal];
		[NSApp terminate:nil];
    }
	pluginMenu = [[self loadSearchPlugins:[SEARCH_PLUGIN_FOLDER stringByAppendingString:@"/"]] retain];
	if(!pluginMenu){
		NSAlert *alert = [[NSAlert alloc] init];
		[alert addButtonWithTitle:@"OK"];
		[alert setMessageText:@"There don't seeem to be any Search plugins."];
		[alert setInformativeText:@"You should have some. Try reinstalling SearchMagic."];
		[alert setAlertStyle:NSWarningAlertStyle];
		[alert runModal];
		[NSApp terminate:nil];
	}
    return pluginMenu;
}

/*- (BOOL)loadResultPlugins
{
    SMLog(@"Loading ResultView Plugins");
    NSString *pname;
    NSMutableDictionary *tempList = [[NSMutableDictionary alloc] init];
    SMResultPlugin *temp;
    //if(!temp) return NO;
    NSDirectoryEnumerator *direnum = [[NSFileManager defaultManager] enumeratorAtPath:[@"~/Library/Application Support/SearchMagic/ResultView Plugins/" stringByExpandingTildeInPath]];
    if(!direnum) return NO;
    while (pname = [direnum nextObject]){
        //it is a resultView plugin...probably.
		if (EQUAL([pname pathExtension], @"resultView")){
			temp = [[SMResultPlugin alloc] init];
			SMLog(@"Found: %@", pname);
			[temp setName:pname];
			pname = [[[@"~/Library/Application Support/SearchMagic/ResultView Plugins/" stringByExpandingTildeInPath] stringByAppendingString:@"/"] stringByAppendingString:[pname stringByAppendingString:@"/"]];
			[temp setHeader:[NSString stringWithContentsOfFile:[pname stringByAppendingString:@"header.html"]]];
			[temp setFooter:[NSString stringWithContentsOfFile:[pname stringByAppendingString:@"footer.html"]]];
			[temp setItem:[NSString stringWithContentsOfFile:[pname stringByAppendingString:@"item.html"]]];
			[temp setItemSpacer:[NSString stringWithContentsOfFile:[pname stringByAppendingString:@"itemspacer.html"]]];
			[temp setTemp:[NSString stringWithContentsOfFile:[pname stringByAppendingString:@"template.html"]]];
			[temp setNoResult:[NSString stringWithContentsOfFile:[pname stringByAppendingString:@"noresult.html"]]];
			[tempList setObject:temp forKey:[temp name]];
		//}else if(EQUAL([[direnum fileAttributes] fileType], NSFileTypeDirectory) && EQUAL_IGNORECASE(pname, @"disabled")){
		//	//Disabled directory. Skip all the inside folders.
		//	[direnum skipDescendents];
		}
    }
    resultPlugins = tempList;
	currentResultPlugin = [resultPlugins objectForKey:[userDefaults objectForKey:@"resultPlugin"]];

	if(!currentResultPlugin){
		currentResultPlugin = [[resultPlugins allKeys] objectAtIndex:0];
		[userDefaults setObject:[[resultPlugins allKeys] objectAtIndex:0] forKey:@"resultPlugin"];
	}
    [pname release];
    [temp release];
    return YES;
}*/

- (BOOL)loadResultPlugins
{
    SMLog(@"Loading ResultView Plugins");
    NSBundle *pluginBundle;
    NSString *pname;
    NSMutableDictionary *tempList = [[NSMutableDictionary alloc] init];
    SMResultPlugin *temp;
    NSDirectoryEnumerator *direnum = [[NSFileManager defaultManager] enumeratorAtPath:[@"~/Library/Application Support/SearchMagic/ResultView Plugins/" stringByExpandingTildeInPath]];
    if(!direnum) return NO;
    while (pname = [direnum nextObject]){
        //it is a resultView plugin...probably.
		if (EQUAL([pname pathExtension], @"resultView")){
			temp = [[SMResultPlugin alloc] init];
			SMLog(@"Found: %@", pname);
			[temp setName:pname];
			pname = [[[@"~/Library/Application Support/SearchMagic/ResultView Plugins/" stringByExpandingTildeInPath] stringByAppendingString:@"/"] stringByAppendingString:[pname stringByAppendingString:@"/"]];
            pluginBundle = [[NSBundle alloc] initWithPath:pname];
            [temp setHeader:[NSString stringWithContentsOfFile:[pluginBundle pathForResource:@"header" ofType:@"html"]]];
			[temp setFooter:[NSString stringWithContentsOfFile:[pluginBundle pathForResource:@"footer" ofType:@"html"]]];
			[temp setItem:[NSString stringWithContentsOfFile:[pluginBundle pathForResource:@"item" ofType:@"html"]]];
			[temp setItemSpacer:[NSString stringWithContentsOfFile:[pluginBundle pathForResource:@"itemspacer" ofType:@"html"]]];
			[temp setTemp:[NSString stringWithContentsOfFile:[pluginBundle pathForResource:@"template" ofType:@"html"]]];
			[temp setNoResult:[NSString stringWithContentsOfFile:[pluginBundle pathForResource:@"noresult" ofType:@"html"]]];
			[tempList setObject:temp forKey:[temp name]];
		//}else if(EQUAL([[direnum fileAttributes] fileType], NSFileTypeDirectory) && EQUAL_IGNORECASE(pname, @"disabled")){
		//	//Disabled directory. Skip all the inside folders.
		//	[direnum skipDescendents];
		}
    }
    resultPlugins = tempList;
	currentResultPlugin = [resultPlugins objectForKey:[userDefaults objectForKey:@"resultPlugin"]];

	if(!currentResultPlugin){
		currentResultPlugin = [[resultPlugins allKeys] objectAtIndex:0];
		SMLog(@"%@", [[resultPlugins allKeys] objectAtIndex:0]);
		[userDefaults setObject:[[resultPlugins allKeys] objectAtIndex:0] forKey:@"resultPlugin"];
	}
    [pname release];
    [temp release];
    return YES;
}

- (BOOL)validateMenuItem:(NSMenuItem*)anItem
{
	if(EQUAL([anItem title], [currentSearchPlugin name]) && ![anItem hasSubmenu]) [anItem setState:NSOnState];
	else [anItem setState:NSOffState];
	return YES;
}

- (NSMenu *)loadSearchPlugins:(NSString *)path
{
    int count = 0;
    NSMenu *searchMenu = [[NSMenu alloc] init];
    NSDictionary *thePlugin;
    NSDirectoryEnumerator *direnum = [[NSFileManager defaultManager] enumeratorAtPath:path];
    SMLog(@"path: %@", path);
    NSString *fileName;
    SMSearchPlugin *tempSearchPlugin;
    while(fileName = [direnum nextObject]){
        if(EQUAL([fileName pathExtension], @"sm")) {
            count++;
            //it is a plugin...probably.
            tempSearchPlugin = [[SMSearchPlugin alloc] init];
            //I have to append / to make it useful.
            fileName = [path stringByAppendingString:fileName];
            thePlugin = [NSDictionary dictionaryWithContentsOfFile:fileName];
            SMLog(@"Found plugin %@", [thePlugin objectForKey:@"name"]);
            
            //go through and assign everything to the SMSearchPlugin.
            [tempSearchPlugin setPost:[[thePlugin objectForKey:@"post"] boolValue]];
            [tempSearchPlugin setName:[thePlugin objectForKey:@"name"]];
            [tempSearchPlugin setTitle:[thePlugin objectForKey:@"title"]];
            [tempSearchPlugin setDesc:[thePlugin objectForKey:@"description"]];
            [tempSearchPlugin setURL:[thePlugin objectForKey:@"url"]];
            [tempSearchPlugin setPreURL:[thePlugin objectForKey:@"preURL"]];
            [tempSearchPlugin setPostURL:[thePlugin objectForKey:@"postURL"]];
            [tempSearchPlugin setExtras:[thePlugin objectForKey:@"extras"]];  //an NSDictionary
            [tempSearchPlugin setFormData:[thePlugin objectForKey:@"formData"]];
            
            //returnData will be an NSDictoinary of SMSearchPlugins with the key being the name.
            [searchPlugins setObject:tempSearchPlugin forKey:[thePlugin objectForKey:@"name"]];
            
            [[searchMenu addItemWithTitle:[thePlugin objectForKey:@"name"] action:@selector(switchPlugin:) keyEquivalent:@""] setTarget:self];
            
            [tempSearchPlugin release];
        }else if(EQUAL([[direnum fileAttributes] fileType], NSFileTypeDirectory)){
            count++;
            SMLog(@"Directory! %@", fileName);
			if(!EQUAL(fileName, @"Disabled")){
				NSMenuItem *temp = [[NSMenuItem alloc] initWithTitle:fileName action:NULL keyEquivalent:@""];
				[temp setSubmenu:[self loadSearchPlugins:[path stringByAppendingString:[fileName stringByAppendingString:@"/"]]]];
				[searchMenu addItem:temp];
				[temp release];
			}
            [direnum skipDescendents];
        }
    }
    if(count == 0) return nil;
    SMLog(@"%@", searchPlugins);
    return [searchMenu autorelease];
}

- (void)setSearchPluginPrefs{
	//load from prefs if there are any. Otherwise, just take the first item.
	if([userDefaults objectForKey:@"searchPlugin"] && [[searchPlugins allKeys] containsObject:[userDefaults objectForKey:@"searchPlugin"]]){
        id<NSMenuItem> menuItem = [[pluginMenu itemWithTitle:[userDefaults objectForKey:@"searchPlugin"] recursive:YES] retain];
		[self switchPlugin:menuItem];
        return;
    }
	SMLog(@"Either you haven't picked a plugin yet, or it changed since last launch.");
    id<NSMenuItem> temp = [pluginMenu itemAtIndex:0];
    //get to the first actual plugin menu item.
    while([temp hasSubmenu]){
        temp = [[temp submenu] itemAtIndex:0];
        SMLog(@"temp: %@", temp);
    }
    [self switchPlugin:temp];
    [userDefaults setObject:[temp title] forKey:@"searchPlugin"];
    SMLog(@"Set current search plugin to: %@", [currentSearchPlugin name]);
}

#pragma mark Switching

- (void)switchPlugin:(id)sender{
	SMLog(@"sender:%@", sender);
	[self setCurrentSearchPlugin:[searchPlugins objectForKey:[sender title]]];
	//post a notification so that we can reload the main view.
	NSNotificationCenter *nc = [NSNotificationCenter defaultCenter];
	[nc postNotificationName:@"ZWReloadView" object:self];
	//set the preference key.
	[userDefaults setObject:[currentSearchPlugin name] forKey:@"searchPlugin"];
    SMLog(@"Switching plugin to...%@", [currentSearchPlugin name]);
}

#pragma mark Accessors

- (NSDictionary *)resultPlugins{
	return resultPlugins;
}

- (SMResultPlugin *)resultPlugin
{
    SMLog(@"Returning the current result plugin: %@", [currentResultPlugin name]);
    return currentResultPlugin;
}

- (SMSearchPlugin *)searchPlugin
{
    SMLog(@"Returning the current search plugin: %@", [currentSearchPlugin name]);
    return currentSearchPlugin;
}

#pragma mark Mutators
- (void)setCurrentSearchPlugin:(SMSearchPlugin *)plugin
{
    [plugin retain];
    [currentSearchPlugin release];
    currentSearchPlugin = plugin;
    SMLog(@"Setting the current search plugin to: %@", plugin);
}

- (void)setCurrentResultPlugin:(SMResultPlugin *)plugin
{
    [plugin retain];
    [currentResultPlugin release];
    currentResultPlugin = plugin;
    SMLog(@"Setting the current result plugin to: %@", plugin);
}

- (id)init
{
    SMLog(@"INIT:SMPluginHander");
    if(self = [super init]) instance = self;
	pluginMenu = [[NSMenu alloc] initWithTitle:@"Search Plugin Menu"];
    searchPlugins = [[NSMutableDictionary alloc] init];
    return self;
}

- (void)dealloc{
    [super dealloc];
    [resultPlugins release];
    [pluginMenu release];
    [searchPlugins release];
    [currentResultPlugin release];
    [currentSearchPlugin release];
}

@end