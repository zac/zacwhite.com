//
//  SMPluginInstaller.m
//  SearchMagic
//
//  Created by Zac White on 8/30/05.
//  Copyright 2005 Zac White. All rights reserved.
//

#import "SMPluginInstaller.h"


@implementation SMPluginInstaller

- (BOOL)installPluginWithPath:(NSString *)path shouldReplace:(BOOL)replace
{
	NSString *extension = [path pathExtension];
	NSString *destination = nil;
	NSString *destinationFilePath = nil;
	NSString *fileDescription = nil;
	NSString *alertMsg = nil;

	BOOL success = YES;
	
	if(EQUAL(extension, @"sm")){
		//it is a search plugin. Install it.
		destination = SEARCH_PLUGIN_FOLDER;
		fileDescription = @"Search plugin";
	}else if(EQUAL(extension, @"resultView")){
		destination = RESULT_PLUGIN_FOLDER;
		fileDescription = @"ResultView plugin";
	}else return NO;
	alertMsg = [NSString stringWithFormat:@"Installation of the %@ \"%@\" was successful.", fileDescription, [path lastPathComponent]];
	destinationFilePath = [destination stringByAppendingPathComponent:[path lastPathComponent]];
	if(!EQUAL(path, destinationFilePath)){
		//Out with the old.
		[[NSFileManager defaultManager] removeFileAtPath:destinationFilePath handler:nil];
		//Create the directory.
		[[NSFileManager defaultManager] createDirectoryAtPath:destination attributes:nil];
		//In with the new.
		if([[NSFileManager defaultManager] copyPath:path toPath:destinationFilePath handler:nil]){
			alertMsg = [NSString stringWithFormat:@"Installation of the %@ \"%@\" was successful.", fileDescription, [path lastPathComponent]];
			success = YES;
		}else{
			alertMsg = [NSString stringWithFormat:@"Installation of the %@ \"%@\" failed.", fileDescription, [path lastPathComponent]];
			success = NO;
		}
	}
	NSRunAlertPanel(success ? @"Installed Plugin" : @"Installation Failed", alertMsg, @"OK", nil, nil);
	[[NSWorkspace sharedWorkspace] noteFileSystemChanged];
	if(success) [[NSNotificationCenter defaultCenter] postNotificationName:@"ZWLoadAllPlugins" object:nil];
	return success;
}

- (BOOL)installPluginFromBundleWithName:(NSString *)name shouldReplace:(BOOL)replace
{
	SMLog(@"name: %@", name);
	NSString *path = [NSString stringWithFormat:@"%@/Plugins/%@", [[NSBundle mainBundle] resourcePath], name];
	SMLog(@"path: %@", path);
	if(!path) return NO;
	NSString *extension = [path pathExtension];
	NSString *destination = nil;
	NSString *destinationFilePath = nil;

	if(EQUAL(extension, @"sm")){
		destination = SEARCH_PLUGIN_FOLDER;
	}else if(EQUAL(extension, @"resultView")){
		destination = RESULT_PLUGIN_FOLDER;
	}else return NO;
	
	destinationFilePath = [destination stringByAppendingPathComponent:[path lastPathComponent]];
	
	//Out with the old.
	BOOL one = [[NSFileManager defaultManager] removeFileAtPath:destinationFilePath handler:nil];
	//In with the new.
	return [[NSFileManager defaultManager] copyPath:path toPath:destinationFilePath handler:nil];
}

- (BOOL)installAllPluginsFromBundle{
	[[NSFileManager defaultManager] createDirectoryAtPath:APP_SUPPORT_FOLDER attributes:nil];
    [[NSFileManager defaultManager] createDirectoryAtPath:SEARCH_PLUGIN_FOLDER attributes:nil];
	[[NSFileManager defaultManager] createDirectoryAtPath:RESULT_PLUGIN_FOLDER attributes:nil];
	
	NSArray *plugins = [[NSArray alloc] initWithObjects:@"google.sm", @"googleimg.sm", @"amazon-books.sm", @"amazon-electronics.sm", @"plain.resultView", nil];
	BOOL flag = YES;
	int i;
	for(i = 0; i < [plugins count]; i++){
		flag = [self installPluginFromBundleWithName:[plugins objectAtIndex:i] shouldReplace:YES];
		SMLog(flag ? @"TRUE":@"FALSE");
	}
	[plugins release];
	[[NSWorkspace sharedWorkspace] noteFileSystemChanged];
	return flag;
}

static id instance = nil;
+ (SMPluginInstaller *)instance
{
    if (!instance) instance = [[SMPluginInstaller alloc] init];
    return instance;
}

- (id)init
{
    SMLog(@"INIT:SMPluginInstaller");
    if(self = [super init]) instance = self;
    return self;
}
@end
