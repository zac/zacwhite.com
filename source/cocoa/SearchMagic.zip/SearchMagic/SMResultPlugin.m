//
//  SMResultPlugin.m
//  SearchMagic
//
//  Created by Zac White on 11/29/04.
//  Copyright 2004 Zac White. All rights reserved.
//
#import "SMResultPlugin.h"

/*!
 * @brief A class that describes a result plugin.
 */
@implementation SMResultPlugin

//#pragma mark Accessors
- (NSString *)bundleName
{
    return resultBundleName;
}

- (NSString *)name
{
    return resultName;
}

- (NSString *)header
{
    return resultHeader;
}

- (NSString *)footer
{
    return resultFooter;
}

- (NSString *)item
{
    return resultItem;
}

- (NSString *)temp
{
    return resultTemp;
}

- (NSString *)noResult
{
    return resultNoResult;
}

#pragma mark Mutators

- (void)setBundleName:(NSString *)bundleName
{
    SMLog(@"Setting bundleName to: %@", bundleName);
    [bundleName retain];
    [resultBundleName release];
    resultBundleName = bundleName;
}

- (void)setName:(NSString *)name
{
    SMLog(@"Setting name to: %@", name);
    [name retain];
    [resultName release];
    resultName = name;
}

- (void)setHeader:(NSString *)header
{
    SMLog(@"Setting header to: %@", header);
    [header retain];
    [resultHeader release];
    resultHeader = header;
}

- (void)setFooter:(NSString *)footer
{
    SMLog(@"Setting footer to: %@", footer);
    [footer retain];
    [resultFooter release];
    resultFooter = footer;
}

- (void)setItem:(NSString *)item
{
    SMLog(@"Setting item to: %@", item);
    [item retain];
    [resultItem release];
    resultItem = item;
}

- (void)setItemSpacer:(NSString *)itemSpacer
{
    SMLog(@"Setting itemSpacer to: %@", itemSpacer);
    [itemSpacer retain];
    [resultItemSpacer release];
    resultItemSpacer = itemSpacer;
}

- (void)setTemp:(NSString *)temp
{
    SMLog(@"Setting template to: %@", temp);
    [temp retain];
    [resultTemp release];
    resultTemp = temp;
}

- (void)setNoResult:(NSString *)noResult
{
	SMLog(@"Setting noResult to:%@", noResult);
	[noResult retain];
	[resultNoResult release];
	resultNoResult = noResult;
}


#pragma mark Token Replacement
//parsed is an NSDictionary with tokens as keys and NSArrays of results like:
// "%title" "blah", "blah2", "blah3", "blah4", "blah5"
// "%url" "http://blah1.com", "http://blah2.com", "http://blah3.com", "http://blah4.com", "http://blah5.com"
//- (NSString *)replaceTokens:(SMSearchPlugin *)plugin tokenValues:(NSDictionary *)parsed{
//    int i;
//    int numResults = [[parsed objectForKey:@"%title"] count];
//    NSLog(@"parsed: %@", parsed);
//    NSRange range;
//    NSMutableString *newHeader, *newFooter, *newTemplate, *source, *newItemSpacer;
//    NSMutableArray *newItem;
//    NSEnumerator *enumerator = [parsed keyEnumerator];
//    id key;
//    //assign all the NSStrings like header and footer to NSMutableStrings so we can play with them.
//    newHeader = [[NSMutableString alloc] init];
//    [newHeader setString:resultHeader];
//    NSLog(@"resultHeader: %@", resultHeader);
//    newFooter = [[NSMutableString alloc] init];
//    [newFooter setString:resultFooter];
//    NSLog(@"resultFooter: %@", resultFooter);
//    newItem = [[NSMutableArray alloc] init];
//    //fills the array with NSMutableStrings containing item.
//    //LEAK!
//    for(i = 0; i < numResults; i++){
//	NSMutableString *tempString = [[NSMutableString alloc] init];
//	[tempString setString:resultItem];
//	NSLog(@"tempString: %@", resultItem);
//	[newItem addObject:tempString];
//	[tempString release];
//    }
//    newItemSpacer = [[NSMutableString alloc] init];
//    [newItemSpacer setString:resultItemSpacer];
//    newTemplate = [[NSMutableString alloc] init];
//    [newTemplate setString:resultTemp];
//    //do it for header. this while loop makes sure that 
//    //while(key = [enumerator nextObject] && ([[parsed objectForKey:key] count] > 0)){
//    while(key = [enumerator nextObject] && [[parsed objectForKey:key] objectAtIndex:0]){
//	do{
//	    NSLog(@"key:%@", key);
//	    range = [resultHeader rangeOfString:key];
//	    if(range.location != NSNotFound){
//		NSLog(@"My theory is correct!");
//		[newHeader replaceCharactersInRange:range withString:[[parsed objectForKey:key] objectAtIndex:0]];
//	    }
//	}while(range.location != NSNotFound);
//    }
//    [enumerator release];
//    //a lot left to do. I have to do all the fancy stuff with NSArrays with counts between 1 and the number of results.
//    //for testing of the plugin loading/switching I say to leave it out for now and just handle 1 and number of results.
//    //now the footer.
//    enumerator = [parsed keyEnumerator];
//    while(key = [enumerator nextObject] && [[parsed objectForKey:key] count] == 1){
//	do{
//	    NSLog(@"key:%@", key);
//	    range = [newFooter rangeOfString:key];
//	    if(range.location != NSNotFound)
//		[newFooter replaceCharactersInRange:range withString:[[parsed objectForKey:key] objectAtIndex:0]];
//	}while(range.location != NSNotFound);
//    }
//    [enumerator release];
//    //now the template
//    enumerator = [parsed keyEnumerator];
//    while(key = [enumerator nextObject] && [[parsed objectForKey:key] count] == 1){
//	do{
//	    NSLog(@"key:%@", key);
//	    range = [newTemplate rangeOfString:key];
//	    if(range.location != NSNotFound)
//		[newTemplate replaceCharactersInRange:range withString:[[parsed objectForKey:key] objectAtIndex:0]];
//	}while(range.location != NSNotFound);
//    }
//    [enumerator release];
//    //now item...hm, maybe I should figure out how I'm going to control the number of results. How about just using title
//    //and letting the plugin writer control the results. I'll suggest having the results set to 5.
//    
//    //now the items.
//    enumerator = [parsed keyEnumerator];
//    for(i = 0; key = [enumerator nextObject] && [[parsed objectForKey:key] count] == numResults; i++){
//	do{
//	    //NSLog(@"key:%@", key);
//	    range = [[newItem objectAtIndex:i] rangeOfString:key];
//	    if(range.location != NSNotFound)
//		[[newItem objectAtIndex:i] replaceCharactersInRange:range withString:[[parsed objectForKey:key] objectAtIndex:i]];
//	}while(range.location != NSNotFound);
//    }
//    [enumerator release];
//    //now put it all together in an NSMutableString that represents the source of our new results page.
//    source = [[NSMutableString alloc] init];
//    [source appendString:newHeader];
//    NSLog(@"%@", newItem);
//    [source appendString:[newItem objectAtIndex:0]];
//    for(i = 1; i <= numResults; i++){
//	[source appendString:newItemSpacer];
//	[source appendString:[newItem objectAtIndex:i-1]];
//	[source appendString:newFooter];
//    }
//    NSLog(@"source:%@", source);
//    //convert NSMutableString to NSData...kinda crappy.
//    //const char *utfString = [source UTF8String];
//    //return [NSData dataWithBytes:utfString length:strlen(utfString)];
//    //[source autorelease];
//    NSString *returnVal = [source description];
//    [source release];
//    //[returnVal autorelease];
//    return nil;
//}

- (NSString *)replaceTokens:(SMSearchPlugin *)plugin tokenValues:(NSDictionary *)parsed
{
    //built in tokens:
    // %engine - the search engine used (name of plugin).
    // %term - the term used to search.
    // %title, %description... - the built in search tokens.
    int numResults = [[parsed objectForKey:@"%title"] count];
    if(numResults == 0){
        NSMutableString *tempNoResult = [[NSMutableString alloc] initWithString:resultNoResult];
        SMLog(@"parsed; %@", [parsed objectForKey:@"%term"]);
		[tempNoResult replaceOccurrencesOfString:@"%term" withString:[[parsed objectForKey:@"%term"] objectAtIndex:0] options:NSCaseInsensitiveSearch range:NSMakeRange(0, [tempNoResult length])];
		[tempNoResult replaceOccurrencesOfString:@"%engine" withString:[[parsed objectForKey:@"%engine"] objectAtIndex:0] options:NSCaseInsensitiveSearch range:NSMakeRange(0, [tempNoResult length])];
		return [tempNoResult autorelease];
    }
    NSMutableDictionary *globals = [[NSMutableDictionary alloc] init];
    NSMutableArray *allItems = [[NSMutableArray alloc] init];
    //build allItems.
    int i;
	//NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
	NSMutableString *tempString;
    for(i = 0; i < numResults; i++){
		tempString = [[NSMutableString alloc] initWithString:resultItem];
        [allItems addObject:tempString];
		[tempString release];
    }
    //NSMutableString *tempItem = [[NSMutableString alloc] init];
    NSMutableString *source = [[NSMutableString alloc] init];
    //get a key enumerator for parsed.
    NSEnumerator *keys = [parsed keyEnumerator];
    //go through each key and get the NSArray which is the value.
    id temp;
    while(temp = [keys nextObject]){
        NSArray *tempArray = [parsed objectForKey:temp];
        //if the NSArray has only one term, it is global and should be replaced everywhere in the final product.
        if([tempArray count] == 1 || [tempArray count] == 0){ //only one item or 0 items. Either way, treat it as global.
            //if the NSArray has only one term, it is global and should be replaced everywhere in the final product.
            [globals setObject:tempArray forKey:temp];
        }else if([tempArray count] == numResults){
            int i;
			//go through each item of the NSArray.
            for(i = 0; i < [tempArray count]; i++){
                int replaceCount = [[allItems objectAtIndex:i] replaceOccurrencesOfString:temp withString:[tempArray objectAtIndex:i] options:NSCaseInsensitiveSearch range:NSMakeRange(0, [[allItems objectAtIndex:i] length])];
			}
        }else{
            NSLog(@"Error: The token named %@ has neither 1(or 0) or the number of results items. This means that the regexp is wrong or maybe a search engine has selectively shown information about sites. This is a feature I do not support. Email me if you would like to see it.", temp);
        }
    }
    //put everything together into source.
    [source appendString:resultHeader];
    for(i = 0; i < [allItems count]; i++){
        [source appendString:[allItems objectAtIndex:i]];
        [source appendString:resultItemSpacer];
    }
    //release allItems because we are done with it.
    [allItems release];
	//[pool release];
    [source appendString:resultFooter];
    
    NSMutableString *finalSource = [[NSMutableString alloc] initWithString:resultTemp];
    [finalSource replaceOccurrencesOfString:@"%body" withString:source options:NSCaseInsensitiveSearch range:NSMakeRange(0, [finalSource length])];
    [source release];
    //deal with the globals.
    keys = [globals keyEnumerator];
    while(temp = [keys nextObject]){
        NSString *replace;
		//only replace globals if there are any.
        if([[globals objectForKey:temp] count] > 0){
            replace = [[globals objectForKey:temp] objectAtIndex:0];
        }else{
            replace = [NSString stringWithString:@""];
        }
        int replaceCount = [finalSource replaceOccurrencesOfString:temp withString:replace options:NSCaseInsensitiveSearch range:NSMakeRange(0, [finalSource length])];
    }
    [self evaluateAllConditionals:finalSource forDict:parsed];
    //don't forget to autorelease something here.
    [globals release];
    return [finalSource autorelease];
}

- (void)evaluateAllConditionals:(NSMutableString *)string forDict:(NSDictionary *)parsed{
    NSRange range = NSMakeRange(0, [string length]);
    int numCond = 0;
    do{
        //find the range of the next if statement.
        range = [string rangeOfString:@"<!--if(" options:NSCaseInsensitiveSearch range:NSMakeRange(range.location +1 , [string length] - (range.location + 1))];
        if(range.location != NSNotFound){
            //this is to parse out the token inbetween the ()s.
            NSRange tokenEnd = [string rangeOfString:@")" options:NSCaseInsensitiveSearch range:NSMakeRange(range.location, [string length] - range.location)];
            //assign the token to a string.
            NSString *token = [string substringWithRange:NSMakeRange(range.location + range.length, tokenEnd.location - (range.location + range.length))];
            //find the end of the whole thing.
            NSRange bigEnd = [string rangeOfString:[NSString stringWithFormat:@"<!--fi(%@)-->", token] options:NSCaseInsensitiveSearch range:NSMakeRange(range.location, [string length] - range.location)];
            //make bigEnd the range of the whole shebang.
            bigEnd = NSMakeRange(range.location, (bigEnd.location + bigEnd.length) - range.location);
            //change token to have a % so we can find it in the dictionary.
            token = [NSString stringWithFormat:@"%@%@", @"%", token];
            //check to see if we want to delete it or not.
            if([parsed objectForKey:token] == nil || [[parsed objectForKey:token] count] == nil){
				//increment the number conditionals.
                numCond++;
                SMLog(@"deleting characters for token %@", token);
				//delete the actual characters.
                [string deleteCharactersInRange:bigEnd];
            }
        }else{
            SMLog(@"Evaluated %i conditional%@", numCond, numCond == 1?@"":@"s");
        }
    }while(range.location != NSNotFound);
}

//- (NSString *)description{
	//return [self name];
//}

- (void)dealloc
{
    [super dealloc];
    [resultBundleName release];
    [resultName release];
    [resultHeader release];
    [resultFooter release];
    [resultItem release];
    [resultItemSpacer release];
    [resultTemp release];
    [resultNoResult release];
}

@end