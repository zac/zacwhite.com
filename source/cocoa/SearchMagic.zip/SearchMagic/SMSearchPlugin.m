//
//  SMSearchPlugin.m
//  SearchMagic
//
//  Created by Zac White on 11/29/04.
//  Copyright 2004 Positron Software. All rights reserved.
//
#import "SMSearchPlugin.h"

/*!
 * @brief A class that describes a search plugin.
 */
@implementation SMSearchPlugin

//#pragma mark Accessors
- (BOOL)post
{
	return post;
}

- (NSString *)path
{
    return path;
}

- (NSString *)name
{
    //NSLog(@"Returning %@", name);
    return name;
}

- (NSString *)version
{
    return version;
}

- (NSString *)preURL
{
    return preURL;
}

- (NSString *)postURL
{
    return postURL;
}

- (NSString *)title
{
    return title;
}

- (NSString *)desc
{
    return desc;
}

- (NSString *)url
{
    return url;
}

- (NSDictionary *)extras
{
    return extras;
}

- (NSDictionary *)formData
{
	return formData;
}

#pragma mark Mutators

- (void)setPost:(BOOL)thePost{
	post = thePost;
}

- (void)setName:(NSString *)theName
{
    [theName retain];
    [name release];
    name = theName;
    SMLog(@"Set the Name of the Plugin to: %@", name);
}

- (void)setDesc:(NSString *)theDesc
{
    SMLog(@"Setting the Description CS to: %@", theDesc);
    [theDesc retain];
    [desc release];
    desc = theDesc;
}

- (void)setURL:(NSString *)theURL
{
    SMLog(@"Setting the the URL CS to: %@", theURL);
    [theURL retain];
    [url release];
    url = theURL;
}

- (void)setTitle:(NSString *)theTitle
{
    SMLog(@"Setting the Title CS to: %@", theTitle);
    [theTitle retain];
    [title release];
    title = theTitle;
}

- (void)setPreURL:(NSString *)thePre
{
    SMLog(@"Setting the Pre URL to %@", thePre);
    [thePre retain];
    [preURL release];
    preURL = thePre;
}

- (void)setPostURL:(NSString *)thePost
{
    SMLog(@"Setting the Post URL to %@", thePost);
    [thePost retain];
    [postURL release];
    postURL = thePost;
}

- (void)setExtras:(NSDictionary *)theExtras
{
    SMLog(@"Setting the Extras CS to: %@", [theExtras description]);
    [theExtras retain];
    [extras release];
    extras = theExtras;
}

- (void)setFormData:(NSDictionary *)theFormData
{
	SMLog(@"Setting the Form Data to: %@", [theFormData description]);
	[theFormData retain];
	[formData release];
	formData = theFormData;
}

#pragma mark Instance
- (NSDictionary *)tokenList{
    NSMutableDictionary *temp = [[NSMutableDictionary alloc] init];
    NSEnumerator *enumerator = [extras keyEnumerator];
    id key;
    [temp setObject:desc forKey:@"%description"];
    [temp setObject:title forKey:@"%title"];
    [temp setObject:url forKey:@"%url"];
    while(key = [enumerator nextObject]){
		[temp setObject:[extras objectForKey:key] forKey:key];
    }
    //2[temp addEntriesFromDictionary:extras];
    SMLog(@"Token List:%@", [temp description]);
    return temp;
}

- (void)dealloc
{
    [super dealloc];
    [path release];
    [name release];
    [description release];
    [version release];
    [preURL release];
    [postURL release];
    [title release];
    [desc release];
    [url release];
    [extras release];
	[formData release];
}


@end
