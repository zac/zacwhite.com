//
//  SMURLRequest.m
//  SearchMagic
//
//  Created by Zac White on 8/9/05.
//  Copyright 2005 Zac White. All rights reserved.
//

#import "SMURLRequest.h"

/*!
 * @brief Handles all the requests for search pages. Has support for POST and GET.
 */
@implementation SMURLRequest

static id instance = nil;
+ (SMURLRequest *)instance
{
    if (!instance) instance = [[SMURLRequest alloc] init];
    return instance;
}

- (NSString *)getResultsWithPlugin:(SMSearchPlugin *)plugin term:(NSString *)searchString
{
    [plugin retain];
    SMLog(@"Here we go");
	NSError *error;
    NSURLResponse *response;
    if([plugin formData] == nil || ![plugin post]){
        NSURL           *userURL;
        NSString	    *theURL;
        theURL = [NSString stringWithFormat:@"%@%@%@", [CURRENT_PLUGIN preURL], searchString, [CURRENT_PLUGIN postURL]];
        SMLog(@"Searching with %@", theURL);
        
        //convert the url string to an NSURL object.
        userURL = [self _urlFromString:theURL];
        SMLog(@"Searching with %@", userURL);

        //check to see if the plugin uses post or get and return the right result.
        return [NSString stringWithContentsOfURL:userURL];
    }
    //we need to use the post data.
    NSData *myData = [NSURLConnection sendSynchronousRequest:[self _createURLRequestWithPlugin:plugin] returningResponse:&response error:&error];
    [plugin release];
    NSString *returnData = [[NSString alloc] initWithData:myData encoding:NSUTF8StringEncoding];
    [myData release];
    return [returnData autorelease];
}

- (id)init
{
    SMLog(@"INIT:SMURLRequest");
    if(self = [super init]) instance = self;
    return self;
}

@end


/******* Private Methods *********/

@implementation SMURLRequest (Private)

- (NSURLRequest *)_createURLRequestWithPlugin:(SMSearchPlugin *)plugin
{
	[plugin retain];
    /** creating the url request */
	NSURL *requestURL = [NSURL URLWithString:[plugin preURL]];
	NSMutableURLRequest *postRequest = [NSMutableURLRequest requestWithURL:requestURL];

	/** adding header information */
	[postRequest setHTTPMethod:@"POST"];

	NSString *stringBoundary = [NSString stringWithString:@"0xKhTmLbOuNdArY"];
	NSString *contentType = [NSString stringWithFormat:@"multipart/form-data; boundary=%@", stringBoundary];
	[postRequest addValue:contentType forHTTPHeaderField: @"Content-Type"];
	[postRequest addValue:[plugin preURL] forHTTPHeaderField:@"Referrer"];

	/** setting up the body */
	NSMutableData *postBody = [NSMutableData data];
	NSEnumerator *fieldEnumerator = [[plugin formData] keyEnumerator];
	NSString *currentField;
	while(currentField = [fieldEnumerator nextObject]){
		[postBody appendData:[self _generateFormDataWithField:currentField andValue:[[plugin formData] objectForKey:currentField]]];
	}
	[postRequest setHTTPBody:postBody];
    [plugin release];
    return postRequest;
}

- (NSData *)_generateFormDataWithField:(NSString *)field andValue:(NSString *)value
{
	NSString *stringBoundary = @"0xKhTmLbOuNdArY";
	NSMutableString *str = [[NSMutableString new] autorelease];

	[str appendString:[NSString stringWithFormat:@"--%@\r\n",stringBoundary]];
	[str appendString:[NSString stringWithFormat:@"Content-Disposition: form-data; name:\"%@\"\r\n\r\n", field]];
	[str appendString:[NSString stringWithString:value]];
	[str appendString:[NSString stringWithFormat:@"\r\n--%@\r\n",stringBoundary]];

	return [str dataUsingEncoding:NSUTF8StringEncoding];
}

-(NSURL *)_urlFromString:(NSString *)inString
{
    NSString *linkString = (NSString *)CFURLCreateStringByAddingPercentEscapes( NULL,
										(CFStringRef)inString,
										(CFStringRef)@":/&=",
										(CFStringRef)@"",
										kCFStringEncodingUTF8 );
    SMLog(@"Converted \"%@\" to \"%@\"",inString,linkString);
    
    NSURL *linkURL = [[NSURL alloc] initWithString:linkString];
    return [linkURL autorelease];
}

@end
