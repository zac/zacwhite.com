//
//  SMPluginHandler.h
//  SearchMagic
//
//  Created by Zac White on 9/9/04.
//  Copyright 2004 Positron Software. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "SMSearchPlugin.h"
#import "SMResultPlugin.h"

@interface SMPluginHandler : NSObject
{
    NSArray		*resultPlugins;
	NSString	*happyFun;
    NSArray		*searchPlugins;
    SMResultPlugin	*currentResultPlugin;
    SMSearchPlugin	*currentSearchPlugin;
}
- (BOOL)loadAllPlugins;
- (void)loadResultPlugins;
- (BOOL)loadSearchPlugins;
- (SMResultPlugin *)currentResultPlugin;
- (SMSearchPlugin *)currentSearchPlugin;
- (void)switchPlugin:(id)sender;
- (void)setCurrentSearchPlugin:(SMSearchPlugin *)plugin;
- (void)setCurrentResultPlugin:(SMResultPlugin *)plugin;
- (id)init;
@end