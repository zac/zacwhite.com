//
//  SMPluginHandler.m
//  SearchMagic
//  Description:
//  This class handles all the plugins that this program is capable of dealing with. Including search and result plugins.
//  If i'm going to add a plugin, it should go in here.
//
//  Created by Zac White on 9/9/04.
//  Copyright 2004 Positron Software. All rights reserved.
//

#import "SMPluginHandler.h"

@implementation SMPluginHandler
- (BOOL)loadAllPlugins{
    NSLog(@"Loading All Plugins");
    [self loadResultPlugins];
}

- (void)switchPlugin:(id)sender{
	NSLog(@"Switching plugin...%@", sender);
}

- (void)loadResultPlugins{
    NSLog(@"Loading ResultView Plugins");
    NSString *pname, *file;
    SMResultPlugin *temp = [SMResultPlugin alloc];
    NSDirectoryEnumerator *direnum = [[NSFileManager defaultManager] enumeratorAtPath:[@"~/Library/Application Support/SearchMagic/ResultView Plugins/" stringByExpandingTildeInPath]];
    while (pname = [direnum nextObject]){
	if ([[pname pathExtension] isEqualToString:@"resultView"]){  //it is a resultView plugin...probably.
	    NSLog(@"Found: %@", pname);
	    pname = [[[@"~/Library/Application Support/SearchMagic/ResultView Plugins/" stringByExpandingTildeInPath] stringByAppendingString:@"/"] stringByAppendingString:[pname stringByAppendingString:@"/"]];
	    [temp setHeader:[NSString stringWithContentsOfFile:[pname stringByAppendingString:@"header.html"]]];
	    [temp setFooter:[NSString stringWithContentsOfFile:[pname stringByAppendingString:@"footer.html"]]];
	    [temp setItem:[NSString stringWithContentsOfFile:[pname stringByAppendingString:@"item.html"]]];
	    [temp setItemSpacer:[NSString stringWithContentsOfFile:[pname stringByAppendingString:@"itemspacer.html"]]];
	    [temp setTemp:[NSString stringWithContentsOfFile:[pname stringByAppendingString:@"template.html"]]];
	    [resultPlugins arrayByAddingObject:temp];
	}
    }
}

- (BOOL)loadSearchPlugins{
}
- (SMResultPlugin *)currentResultPlugin{
    return currentResultPlugin;
}
- (SMSearchPlugin *)currentSearchPlugin{
}
- (void)setCurrentSearchPlugin:(SMSearchPlugin *)plugin{
}
- (void)setCurrentResultPlugin:(SMResultPlugin *)plugin{
}
- (id)init{
	NSLog(@"INIT:SMResultPlugin");
	if(self = [super init]){
		[self loadAllPlugins];
    }
    return self;
}
@end
