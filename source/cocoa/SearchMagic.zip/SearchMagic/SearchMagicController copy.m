#import "SearchMagicController.h"
#import "PSContextSearch.h"

#define currentPlugin [[SMPluginHandler instance] searchPlugin]

@implementation SearchMagicController

- (void)awakeFromNib
{	
    //pluginHandler = [[SMPluginHandler alloc] init];
    //if(pluginHandler == nil) NSLog(@"IT IS NIL");
    id searchCell = [searchField cell];
    [searchCell setSearchMenuTemplate:[[SMPluginHandler instance] loadAllPlugins]];
    	//if ([myWindow respondsToSelector:@selector(setBottomCornerRounded:)]){
    [resultView setPolicyDelegate:self];
	//}
    //pluginData = [self loadPlugins];
    //SMSearchPlugin *temp = [[SMPluginHandler instance] searchPlugin];
    //currentPlugin = [[[SMPluginHandler instance] searchPlugin] retain];
    //NSLog(@"current:%@", [currentPlugin name]);
    //NSLog(@"%@", [pluginHandler  description]);//[self resizeTheWindow:myWindow theHeight:36 doAnimation:NO];
}

#pragma mark Searching and Parsing
- (IBAction)search:(id)sender
{
    NSMutableData   *response;
    NSURL           *userURL;
    NSString	    *theURL;
    
    if([[searchField stringValue] isEqualToString:@""]) return;
        [progress startAnimation:nil];
        //    NS_DURING
        //build URL string. This should be made plugin specific soon. In fact, the plugins don't even have this value in them...better change that soon.
        theURL = [NSString stringWithFormat:@"%@%@%@", [currentPlugin preURL], [searchField stringValue], [currentPlugin postURL]];
        NSLog(@"Searching with %@", theURL);
		
        //convert the url string to an NSURL object.
        //userURL = [NSURL URLWithString:theURL];
        userURL = [[self setURLFromString:theURL] retain];
        NSLog(@"Searching with %@", userURL);
        //When connected to the net.
        //fetch the data with the recently created NSURL object.
	//NSString *firstResponse = [NSString stringWithContentsOfURL:userURL];
	//response = [NSData dataWithBytes:[firstResponse cString]];
        response = [NSData dataWithContentsOfURL:userURL];
        //NSLog(@"source:%@", [NSString stringWithContentsOfURL:userURL]);
        //When not connected to the net.
        //get the data from a local file.
        //response = [NSData dataWithContentsOfFile:@"/googletest.txt"];
	
        //parse and display the data in the webView.	
        mainFrame = [resultView mainFrame];
        /*
        [mainFrame loadData:[self parseContent:response] MIMEType:@"text/html" textEncodingName:@"UTF-8" 
		    baseURL:[NSURL URLWithString:[@"http://" stringByAppendingString:[userURL host]]]];
        [[self parseContent:response] retain] */
        //[self parseContent:response];
        [mainFrame loadHTMLString:[[self parseContent:response] retain]
			  baseURL:[NSURL URLWithString:[@"http://" stringByAppendingString:[userURL host]]]];
        [progress stopAnimation:nil];
        //    NS_HANDLER
        //        // If an exception occurs, display its description with NSLog
        //        NSLog(@"Exception: %@", [localException description]);        
        //    NS_ENDHANDLER
}

-(void)doSearch{
    
}

-(NSURL *)setURLFromString:(NSString *)inString
{
    NSString *linkString = (NSString *)CFURLCreateStringByAddingPercentEscapes( NULL,
										(CFStringRef)inString,
										(CFStringRef)@":/&=",
										(CFStringRef)@"",
										kCFStringEncodingUTF8 );
    NSLog(@"Converted \"%@\" to \"%@\"",inString,linkString);
    
    NSURL *linkURL = [[NSURL alloc] initWithString:linkString];
    return [linkURL autorelease];
}

- (NSString *)parseContent:(NSData *)rawText
{
    //AGRegex *regex = [[AGRegex alloc] initWithPattern:@"[\n\r]"];
    NSLog(@"Parsing content");
    //currentPlugin = [pluginHandler searchPlugin];
    NSEnumerator *enumerator = [[currentPlugin extras] keyEnumerator];
    NSLog(@"1");
    SMResultPlugin *plugin = [[[SMPluginHandler instance] resultPlugin] retain];
    //NSLog(@"plugin's thing: %@", [plugin header]);
    NSMutableDictionary *bigList = [[NSMutableDictionary alloc] init];
    PSContextSearch *search = [[PSContextSearch alloc] init];
    //NSArray *title, *desc, *url;
    //NSMutableArray *extras = [[NSMutableArray alloc] init];
    //NSLog(@"Raw Data: %@", rawText);
    NSString *preData = [[NSString alloc] initWithData:rawText encoding:NSUTF8StringEncoding];
    NSMutableString *lines = [[NSMutableString alloc] init];
    [lines setString:[[NSString alloc] initWithData:rawText encoding:NSUTF8StringEncoding]];
    NSLog(@"Removing returns");
    NSLog(@"Data: %@", preData);
    //NSString *data = [regex replaceWithString:@"" inString:preData];
    [lines replaceOccurrencesOfString:@"\n" withString:@"" options:nil range:NSMakeRange(0, [lines length])];
    [lines replaceOccurrencesOfString:@"\r" withString:@"" options:nil range:NSMakeRange(0, [lines length])];
    NSString *data = [lines description];
    NSLog(@"Returns removed");
    [preData release];
    //NSLog(@"data: %@",data);
    //title = [search extractAllOccurrences:data cs:[currentPlugin objectForKey:@"title"]];
    NSLog(@"2");
    [bigList setObject:[[search extractAllOccurrences:data cs:[currentPlugin title]] retain] forKey:@"%title"];
    NSLog(@"3");
    [bigList setObject:[NSArray arrayWithObject:[[searchField stringValue] retain]] forKey:@"%term"];
    [bigList setObject:[NSArray arrayWithObject:[[[SMPluginHandler instance] searchPlugin] name]] forKey:@"%engine"];
	[bigList setObject:[NSArray arrayWithObject:[NSString stringWithFormat:@"file:///Users/zac/Library/Application Support/SearchMagic/ResultView Plugins/%@", [plugin name]]] forKey:@"%support"];
    //desc = [search extractAllOccurrences:data cs:[currentPlugin objectForKey:@"description"]];
    //NSLog(@"Parsed so far:%@", [bigList description]);
    [bigList setObject:[[search extractAllOccurrences:data cs:[currentPlugin desc]] retain] forKey:@"%description"];
    NSLog(@"3");
    //url = [search extractAllOccurrences:data cs:[currentPlugin objectForKey:@"url"]];
    [bigList setObject:[[search extractAllOccurrences:data cs:[currentPlugin url]] retain] forKey:@"%url"];
    //NSLog(@"Parsed so far:%@", [bigList description]);
    id key;
    while((key = [enumerator nextObject])){
        NSLog(@"loading:%@", key);
        [bigList setObject:[[search extractAllOccurrences:data cs:[[currentPlugin extras] objectForKey:key]] retain] forKey:key];
        //NSLog(@"CS:%@", [[currentPlugin extras] objectForKey:key]);
    }
    //NSLog(@"*** is:%@", [desc description]);
    //NSLog(@"*** is:%@", [[search extractAllOccurrences:data cs:@"<p class=g><a href=*.*>***</a>"] description]);
    NSLog(@"Parsed so far:%@", [bigList description]);
    //[search release];
    NSString *tempData = [[plugin replaceTokens:currentPlugin tokenValues:bigList] retain];
    [plugin release];
    [tempData autorelease];
    return tempData;
}

#pragma mark Plugin Loading and Switching
- (NSMutableArray*)loadPlugins{
    int count = 0;
    NSDictionary *thePlugin;
    NSMutableArray *returnData = [[NSMutableArray alloc] init];
    NSDirectoryEnumerator *direnum = [[NSFileManager defaultManager] enumeratorAtPath:[@"~/Library/Application Support/SearchMagic/Search Plugins/" stringByExpandingTildeInPath]];
    NSString *pname;
    //NSMenu *searchMenu = [[[NSMenu alloc] initWithTitle:@"Plugin Menu"] autorelease];
    searchMenu = [[[NSMenu alloc] initWithTitle:@"Plugin Menu"] autorelease];	
    NSMenuItem *temp;
    id searchCell = [searchField cell];
    //NSLog(@"1");
    while (pname = [direnum nextObject]) {
	//NSLog(@"2");
	if ([[pname pathExtension] isEqualToString:@"sm"]) {
	    //it is a plugin...probably.
	    pname = [[[@"~/Library/Application Support/SearchMagic/Search Plugins/" stringByExpandingTildeInPath] stringByAppendingString:@"/"] stringByAppendingString:pname]; //stringByExpandingTildeInPath is stupid!
	    //NSLog(@"3 %@", pname);
	    thePlugin = [NSDictionary dictionaryWithContentsOfFile:pname];
	    NSLog(@"Found plugin %@", [thePlugin objectForKey:@"name"]);
	    [returnData addObject:thePlugin];
		temp = [[NSMenuItem alloc] initWithTitle:[thePlugin objectForKey:@"name"] action:@selector(switchPlugin) keyEquivalent:@""];
	    [temp setTarget:[[SMPluginHandler instance] retain]];
	    [searchMenu insertItem:temp atIndex:count];
	    [temp release];
	    count++;
	}
    }
    [searchCell setSearchMenuTemplate:searchMenu];
    //NSLog(@"4 %@", [returnData description]);
    return returnData;
}

- (void)webView:(WebView *)sender decidePolicyForNewWindowAction:(NSDictionary *)actionInformation request:(NSURLRequest *)request newFrameName:(NSString *)frameName decisionListener:(id<WebPolicyDecisionListener>)listener {
    NSLog(@"Link clicked");
    [[NSWorkspace sharedWorkspace] openURL:[request URL]];
}

- (void)switchPlugin{}
@end
