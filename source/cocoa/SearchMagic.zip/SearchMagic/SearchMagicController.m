#import "SearchMagicController.h"
#import "SMPluginInstaller.h"
/*#import "PSContextSearch.h"
#import "PreferencesController.h"
#import "SMURLRequest.h"*/

/*!
 * @brief This is the main controller for the main window.
 */
@implementation SearchMagicController

/*!
 * @brief This is called first thing. This method sets up the search menu and loads all the plugins. It also registers some notifications.
 */
- (void)awakeFromNib
{
	firstTime = NO;
    id searchCell = [searchField cell];
    BOOL isDir;
	if(![[NSFileManager defaultManager] fileExistsAtPath:APP_SUPPORT_FOLDER]){
		if([userDefaults objectForKey:@"resultPlugin"] == nil){
			NSAlert *alert = [[NSAlert alloc] init];
			[alert addButtonWithTitle:@"OK"];
			[alert setMessageText:@"Welcome to SearchMagic!"];
			[alert setInformativeText:@"Since this is the first time you have used SearchMagic, SearchMagic will now install plugins to your Application Support directory. These plugins will allow you to search a variety of websites and make them look a couple different ways. You should consider getting more plugins from Plugins > Get More Plugins... option. Enjoy!"];
			[alert setAlertStyle:NSInformationalAlertStyle];
			[alert runModal];
		}
		firstTime = YES;
        [[SMPluginInstaller instance] installAllPluginsFromBundle];
	}
	[[SMPluginHandler instance] loadAllPlugins];
	[searchCell setSearchMenuTemplate:[[SMPluginHandler instance] pluginMenu]];
    [[SMPluginHandler instance] setSearchPluginPrefs];
	[searchCell setPlaceholderString:[CURRENT_PLUGIN name]];
	[myWindow setTitle:[@"SearchMagic - " stringByAppendingString:[CURRENT_PLUGIN name]]];
	if ([myWindow respondsToSelector:@selector(setBottomCornerRounded:)])
		[myWindow setBottomCornerRounded:NO];
		
	//observe a notification so that we can reload the main view.
	NSNotificationCenter *nc = [NSNotificationCenter defaultCenter];
	[nc addObserver:self selector:@selector(reload:) name:@"ZWReloadView" object:nil];
	[nc addObserver:self selector:@selector(changeSearchAsYouType:) name:@"ZWSearchAsYouType" object:nil];
	[nc addObserver:self selector:@selector(loadAllPlugins:) name:@"ZWLoadAllPlugins" object:nil];
	[nc postNotificationName:@"ZWSearchAsYouType" object:NBOOL([userDefaults integerForKey:@"searchAsYouType"])];
    [resultView setPolicyDelegate:self];
	mainFrame = [resultView mainFrame];
	[mainFrame loadHTMLString:@"" baseURL:nil];
	[myWindow center];
	[myWindow makeKeyAndOrderFront:self];
}

- (void)loadAllPlugins:(NSNotification *)note{
	id searchCell = [searchField cell];
	[searchCell setSearchMenuTemplate:[[SMPluginHandler instance] loadAllPlugins]];
    [[SMPluginHandler instance] setSearchPluginPrefs];
	[searchCell setPlaceholderString:[CURRENT_PLUGIN name]];
	[myWindow setTitle:[@"SearchMagic - " stringByAppendingString:[CURRENT_PLUGIN name]]];
}

#pragma mark Searching and Parsing
- (IBAction)search:(id)sender
{
	if(firstTime){
		firstTime = NO;
		SMLog(@"fistTime");
		[[NSNotificationCenter defaultCenter] postNotificationName:@"ZWLoadAllPlugins" object:nil];
	}
	[NSThread detachNewThreadSelector:@selector(doSearch) toTarget:self withObject:nil];
}

- (void)doSearch
{
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
	    
    if(!EQUAL([searchField stringValue], @"")){
        if([userDefaults integerForKey:@"progressIndicator"] == NSOnState) [progress startAnimation:nil];
        //do it.
		NSString *firstResponse = [[SMURLRequest instance] getResultsWithPlugin:CURRENT_PLUGIN term:[searchField stringValue]];
        NSMutableArray *array =[[NSMutableArray alloc] init];
		[array insertObject:[self parseContent:firstResponse] atIndex:0];
		[array insertObject:[NSURL URLWithString:[@"http://" stringByAppendingString:[[NSURL URLWithString:[CURRENT_PLUGIN preURL]] host]]] atIndex:1];
		[self performSelectorOnMainThread:@selector(updateWebView:) withObject:array waitUntilDone:YES];
		[array release];
        if([userDefaults integerForKey:@"progressIndicator"] == NSOnState) [progress stopAnimation:nil];
    }else{
		[self performSelectorOnMainThread:@selector(updateWebView:) withObject:[NSArray arrayWithObject:@""] waitUntilDone:NO];
    }
	[pool release];
}


- (void)reload:(NSNotification *)note
{
	[[searchField cell] setPlaceholderString:[CURRENT_PLUGIN name]];
	[myWindow setTitle:[@"SearchMagic - " stringByAppendingString:[CURRENT_PLUGIN name]]];
	[self search:searchField];
}

- (void)updateWebView:(NSArray *)data{
	[data retain];
	if(!mainFrame) mainFrame = [resultView mainFrame];
	if([data count] == 1) [mainFrame loadHTMLString:[[data objectAtIndex:0] retain] baseURL:nil];
	else [mainFrame loadHTMLString:[[data objectAtIndex:0] retain] baseURL:[data objectAtIndex:1]];
	[data release];
}

- (void)changeSearchAsYouType:(NSNotification *)note
{
	BOOL flag = ![[note object] boolValue];
	[[searchField cell] setSendsWholeSearchString:flag];
}

#pragma mark Opening/Installing Plugins

- (BOOL)application:(NSApplication *)theApplication openFile:(NSString *)filename{
	SMLog(@"File %@ opened!", filename);
	return [[SMPluginInstaller instance] installPluginWithPath:filename shouldReplace:YES];
}


- (NSString *)parseContent:(NSString *)rawText
{
    [rawText retain];
    SMLog(@"Parsing content");
	SMLog(@"Extras: %@", [CURRENT_PLUGIN extras]);
    NSEnumerator *enumerator = [[CURRENT_PLUGIN extras] keyEnumerator];
    SMLog(@"1");
    SMResultPlugin *plugin = [[[SMPluginHandler instance] resultPlugin] retain];
    NSMutableDictionary *bigList = [[NSMutableDictionary alloc] init];
    PSContextSearch *search = [[PSContextSearch alloc] init];
    NSMutableString *lines = [[NSMutableString alloc] init];
    [lines setString:[[NSString alloc] initWithString:rawText]];
    SMLog(@"Removing returns");
    [lines replaceOccurrencesOfString:@"\n" withString:@"" options:nil range:NSMakeRange(0, [lines length])];
    [lines replaceOccurrencesOfString:@"\r" withString:@"" options:nil range:NSMakeRange(0, [lines length])];
    NSString *data = [lines description];
    SMLog(@"Returns removed");
    SMLog(@"2");
    [bigList setObject:[search extractAllOccurrences:data cs:[CURRENT_PLUGIN title]] forKey:@"%title"];
    SMLog(@"3");
    [bigList setObject:[NSArray arrayWithObject:[searchField stringValue]] forKey:@"%term"];
    [bigList setObject:[NSArray arrayWithObject:[[[SMPluginHandler instance] searchPlugin] name]] forKey:@"%engine"];
    [bigList setObject:[NSArray arrayWithObject:[NSString stringWithFormat:@"file:///Users/zac/Library/Application Support/SearchMagic/ResultView Plugins/%@/Contents/Resources", [plugin name]]] forKey:@"%support"];
    [bigList setObject:[search extractAllOccurrences:data cs:[CURRENT_PLUGIN desc]] forKey:@"%description"];
    SMLog(@"4");
    [bigList setObject:[search extractAllOccurrences:data cs:[CURRENT_PLUGIN url]] forKey:@"%url"];
    id key;
    while(key = [enumerator nextObject]){
        SMLog(@"loading:%@", key);
        [bigList setObject:[search extractAllOccurrences:data cs:[[CURRENT_PLUGIN extras] objectForKey:key]] forKey:key];
    }
    SMLog(@"Parsed so far:%@", [bigList description]);
    NSString *tempData = [plugin replaceTokens:CURRENT_PLUGIN tokenValues:bigList];
    [plugin release];
	[search release];
	[bigList release];
    [tempData autorelease];
    [rawText release];
    return tempData;
}

#pragma mark WebView Link Policy
- (void)webView:(WebView *)sender decidePolicyForNewWindowAction:(NSDictionary *)actionInformation request:(NSURLRequest *)request newFrameName:(NSString *)frameName decisionListener:(id<WebPolicyDecisionListener>)listener
{
    SMLog(@"Link clicked");
    [[NSWorkspace sharedWorkspace] openURL:[request URL]];
}

- (void)dealloc
{
	//unregister the notification.
	[[NSNotificationCenter defaultCenter] removeObserver:self];
	[super dealloc];
}

@end