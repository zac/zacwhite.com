#import "UpdateController.h"

/*!
 * @brief Controls the interface and installing of plugins through the Update system.
 */
@implementation UpdateController

- (void)awakeFromNib
{
    pluginList = [[[SMPluginDownloader instance] downloadPluginList] retain];
    count = [[pluginList objectForKey:@"Order"] count];
    installNumber = 0;
    checked = [[NSMutableArray alloc] init];
    int i;
    for(i = 0; i < count; i++){
		[checked addObject:NBOOL(NO)];
    }
    [pluginView reloadData];
	[pluginList release];
}

- (IBAction)install:(id)sender
{
    [myWindow setTitle:@"Preferences : Installing..."];
    NSView *tempView = [[NSView alloc] initWithFrame:[[myWindow contentView] frame]];
    [myWindow setContentView:tempView];
    [tempView release]; 
    
    NSRect newFrame = [myWindow frame];
    newFrame.size.height = [installView frame].size.height + ([myWindow frame].size.height - [[myWindow contentView] frame].size.height);
    newFrame.size.width = [installView frame].size.width;
    newFrame.origin.y += ([[myWindow contentView] frame].size.height - [installView frame].size.height);
    
    [myWindow setShowsResizeIndicator:YES];
    [myWindow setFrame:newFrame display:YES animate:YES];
    [myWindow setContentView:installView];
    [self doInstall];
}

- (IBAction)installStop:(id)sender{
    [myWindow setTitle:@"Preferences : Update"];
    NSView *tempView = [[NSView alloc] initWithFrame:[[myWindow contentView] frame]];
    [myWindow setContentView:tempView];
    [tempView release]; 
    
    NSRect newFrame = [myWindow frame];
    newFrame.size.height = [browseView frame].size.height + ([myWindow frame].size.height - [[myWindow contentView] frame].size.height);
    newFrame.size.width = [browseView frame].size.width;
    newFrame.origin.y += ([[myWindow contentView] frame].size.height - [browseView frame].size.height);
    
    [myWindow setShowsResizeIndicator:YES];
    [myWindow setFrame:newFrame display:YES animate:YES];
    [myWindow setContentView:browseView];
}

- (void)doInstall
{
    //do the actually installation here and update the progress indicators.
    //for loop through the checked items.
    //call [[SMPluginDownloader instance] downloadSearchPlugin:[NSURL urlWithString:theURL]] for each.
    //between plugins, update the icons and such.
    int i;
    for(i = 0; i < [checked count]; i++){
	if([[checked objectAtIndex:i] boolValue]){
	    //weird conversion from array value to dictionary.
	    NSDictionary *pluginInfo = [pluginList objectForKey:[[pluginList objectForKey:@"Order"] objectAtIndex:i]];
	    NSString *type = [pluginInfo objectForKey:@"type"];
	    NSString *name = [pluginInfo objectForKey:@"filename"];
	    if(EQUAL(type, @"Search")) [[SMPluginDownloader instance] downloadSearchPlugin:name];
	    else if(EQUAL(type, @"Result")) [[SMPluginDownloader instance] downloadResultPlugin:name];
	}
    }
}

- (void)tableView:(NSTableView *)aTableView setObjectValue:(id)theObject forTableColumn:(NSTableColumn *)aTableColumn row:(int)rowIndex
{
    if(EQUAL([aTableColumn identifier], @"checked")){
	if([theObject boolValue]) installNumber++;
	else installNumber--;
	[checked replaceObjectAtIndex:rowIndex withObject:NBOOL([theObject boolValue])];
	[self _updateButton];
    }
    [pluginView reloadData];
}

- (id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(int)rowIndex
{
    //SMLog(@"Getting info for %@", [aTableColumn identifier]);
    if(EQUAL([aTableColumn identifier], @"stateIcon")){
	return [[NSImage alloc] init];
    }else if(EQUAL([aTableColumn identifier], @"checked")){
	return [checked objectAtIndex:rowIndex];
    }else if(EQUAL([aTableColumn identifier], @"size")){
	return [NSString stringWithFormat:@"%@ kb",[[pluginList objectForKey:[[pluginList objectForKey:@"Order"] objectAtIndex:rowIndex]] objectForKey:@"size"]];
    }
    return [[pluginList objectForKey:[[pluginList objectForKey:@"Order"] objectAtIndex:rowIndex]] objectForKey:[aTableColumn identifier]];  
}

- (int)numberOfRowsInTableView:(NSTableView *)aTableView
{
    return count;
}

- (void)_updateButton{
    if(installNumber > 0){
	[installButton setEnabled:YES];
	NSString *format = [NSString stringWithString:@"Install %i Item"];
	if(installNumber > 1) format = [format stringByAppendingString:@"s"];
	[installButton setTitle:[NSString stringWithFormat:format, installNumber]];
	//[format release];
    }else{
	[installButton setTitle:@"Install"];
	[installButton setEnabled:NO];
    }
}

//- (id)init
//{
//	pluginList = [[SMPluginDownloader instance] downloadPluginList];
//	return [super init];
//}
    
- (void)dealloc
{
    [super dealloc];
    [pluginList release];
    [checked release];
}

@end
