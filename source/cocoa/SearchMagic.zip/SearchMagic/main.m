//
//  main.m
//  SearchMagic
//
//  Created by Zac White on 9/1/04.
//  Copyright __MyCompanyName__ 2004. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
