#!/bin/sh

SITE="http://homepage.mac.com/zacwhite/plugins/"

#check params.
if [ $# -ne 2 ]; then
    echo "Please do not use this unless you know what you are doing!"
    exit 1
fi
TYPE=""
if [ "$1" = "-r" ]; then
    TYPE="result"
fi

if [ "$1" = "-s" ]; then
    TYPE="search"
fi

#download the file. It should be in result/ or search/ depending.
SITE=$SITE$TYPE/$2
curl -s $SITE -o /tmp/$2 >> /dev/null

if [ $? -ne 0 ]; then
    exit $? + 1
fi

file /tmp/$2 | grep "Zip" >> /dev/null
NAME=$2

if [ "$TYPE" = "result" ] && [ $? -eq 0 ]; then
    NAME=`echo -n $2 | sed s/\\.zip//`
    unzip /tmp/$2 -d /tmp >> /dev/null
    if [ -e /Users/$USER/Library/Application\ Support/SearchMagic/ResultView\ Plugins/$NAME ]; then
	rm /tmp/$2
	rm -rf /tmp/$NAME
	rm -rf /tmp/__MACOSX/
	exit 1
    fi
    mv /tmp/$NAME /Users/$USER/Library/Application\ Support/SearchMagic/ResultView\ Plugins/
    rm /tmp/$2
    rm -rf /tmp/__MACOSX/
fi

if [ "$TYPE" = "search" ]; then
    if [ -e /Users/$USER/Library/Application\ Support/SearchMagic/Search\ Plugins/$NAME ]; then
	rm /tmp/$2
	exit 1
    fi
    mv /tmp/$NAME /Users/$USER/Library/Application\ Support/SearchMagic/Search\ Plugins/
fi

exit 0;

